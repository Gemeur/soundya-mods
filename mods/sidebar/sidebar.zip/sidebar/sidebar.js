// Soundya Sidebar & Navigation Drawer Mod with iOS-style Reorganized Settings
(() => {
  const MOD_ID = 'sidebar';

  // Main menu items:
  const MAIN_MENU = [
    {
      id: 'home',
      title: 'Главная',
      icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9.5L12 3l9 6.5V20a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9.5z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>'
    },
    {
      id: 'mine',
      title: 'Моя музыка',
      icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>'
    },
    {
      id: 'plans',
      title: 'Планы',
      icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>'
    },
    {
      id: 'remote',
      title: 'Пульт',
      icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="7" y="2" width="10" height="20" rx="3"/><circle cx="12" cy="14" r="2"/><line x1="12" y1="6" x2="12" y2="6.01"/></svg>'
    },
    {
      id: 'glow',
      title: 'Подсветка',
      icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>'
    },
    {
      id: 'settings',
      title: 'Настройки',
      icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>'
    },
  ];

  // Reorganized Settings subnav (analogous to iOS / phone settings):
  const SETTINGS_SUBMENU = [
    { id: 'services', title: 'Сервисы' },
    { id: 'automations', title: 'Автоматизации' },
    { id: 'sound', title: 'Звук и голос' },
    { id: 'display', title: 'Экран и вид' },
    { id: 'plans', title: 'Планировщик' },
    { id: 'mods', title: 'Моды' },
    { id: 'system', title: 'Система' },
  ];

  // Legacy mappings for deep links:
  const LEGACY_MAP = {
    'net': 'services',
    'account': 'services',
    'devices': 'services',
    'speaker': 'system',
    'light': 'display',
    'look': 'display',
    'about': 'system',
    'plans': 'plans',
    'mods': 'mods',
    'system': 'system',
    'services': 'services',
    'automations': 'automations',
    'sound': 'sound',
    'display': 'display'
  };

  let observer = null;
  let isOpen = false;

  // Helper to find a section card (either wrapped as details.psect or by H2 / ID)
  function findCard(parent, query) {
    if (!parent) return null;
    if (query.startsWith('#') || query.startsWith('.')) {
      const el = parent.querySelector(query);
      if (el) return el.closest('details.psect') || el;
    }
    const qLower = query.toLowerCase();
    const cards = parent.querySelectorAll('details.psect');
    for (const card of cards) {
      const sum = card.querySelector('summary');
      if (sum && sum.textContent.trim().toLowerCase().includes(qLower)) {
        return card;
      }
    }
    const h2s = parent.querySelectorAll('h2');
    for (const h of h2s) {
      if (h.textContent.trim().toLowerCase().includes(qLower)) {
        return h.closest('details.psect') || h;
      }
    }
    return null;
  }

  // Create clean iOS-style section category group header
  function createGroupHeader(title, subtitle) {
    const wrap = document.createElement('div');
    wrap.className = 'soundya-group-header';
    wrap.innerHTML = `
      <div class="soundya-group-title">${title}</div>
      ${subtitle ? `<div class="soundya-group-subtitle">${subtitle}</div>` : ''}
    `;
    return wrap;
  }

  // Main DOM reorganization:
  function reorganizeSettingsTabs() {
    if (document.getElementById('sub-services')) return;

    const settingsTab = document.getElementById('tab-settings');
    if (!settingsTab) return;

    // Original containers
    const netSub = settingsTab.querySelector('.sub[data-sub="net"]');
    const accountSub = settingsTab.querySelector('.sub[data-sub="account"]');
    const speakerSub = settingsTab.querySelector('.sub[data-sub="speaker"]');
    const lightSub = settingsTab.querySelector('.sub[data-sub="light"]');
    const lookSub = settingsTab.querySelector('.sub[data-sub="look"]');
    const devicesSub = settingsTab.querySelector('.sub[data-sub="devices"]');
    const aboutSub = settingsTab.querySelector('.sub[data-sub="about"]');
    const plansSub = settingsTab.querySelector('.sub[data-sub="plans"]');

    if (!speakerSub || !devicesSub) return;

    // =========================================================================
    // 1. EXTRACT FROM "SPEAKER":
    // =========================================================================
    // a) Music default
    const mdEl = speakerSub.querySelector('#musicdefault');
    let musicCard = null;
    if (mdEl) {
      musicCard = document.createElement('details');
      musicCard.className = 'psect soundya-extracted-card';
      musicCard.id = 'sect-musicdefault';
      musicCard.open = true;
      musicCard.innerHTML = `<summary>Музыка по умолчанию</summary>`;
      const wrap = document.createElement('div');
      const label = mdEl.previousElementSibling;
      const hint = mdEl.nextElementSibling;
      if (label && label.classList.contains('field')) wrap.appendChild(label);
      wrap.appendChild(mdEl);
      if (hint && hint.id === 'musichint') wrap.appendChild(hint);
      musicCard.appendChild(wrap);
    }

    // b) Alarm
    const akEl = speakerSub.querySelector('#alarmkind');
    let alarmCard = null;
    if (akEl) {
      alarmCard = document.createElement('details');
      alarmCard.className = 'psect soundya-extracted-card';
      alarmCard.id = 'sect-alarm';
      alarmCard.open = true;
      alarmCard.innerHTML = `<summary>Будильник</summary>`;
      const wrap = document.createElement('div');
      const label = akEl.previousElementSibling;
      const hint = akEl.nextElementSibling;
      const volBox = speakerSub.querySelector('#alarmvolbox');
      if (label && label.classList.contains('field')) wrap.appendChild(label);
      wrap.appendChild(akEl);
      if (hint && hint.id === 'alarmhint') wrap.appendChild(hint);
      if (volBox) wrap.appendChild(volBox);
      alarmCard.appendChild(wrap);
    }

    // c) Equalizer, Alice Voice, Ducking
    const eqCard = findCard(speakerSub, 'Эквалайзер');
    const voiceCard = findCard(speakerSub, '#voicesection');
    const duckCard = findCard(speakerSub, '#ducksection');

    // d) AirPlay
    const airplayCard = findCard(speakerSub, 'AirPlay');

    // e) Rename remaining "Колонка" card to "Параметры колонки"
    const spkCard = findCard(speakerSub, 'Колонка');
    if (spkCard) {
      const sum = spkCard.querySelector('summary');
      if (sum) sum.textContent = 'Параметры колонки';
    }

    // =========================================================================
    // 2. EXTRACT FROM "DEVICES":
    // =========================================================================
    const pcCard = findCard(devicesSub, 'Компьютер');
    const btCard = findCard(devicesSub, '#btsection');
    const tvCard = findCard(devicesSub, '#tvsection');
    const tgCard = findCard(devicesSub, '#tgsection');
    const macroCard = findCard(devicesSub, '#macrosection');
    const autoCard = findCard(devicesSub, '#autosection');

    // =========================================================================
    // 3. EXTRACT FROM "PLANS" & "LIGHT":
    // =========================================================================
    let timerCard = null;
    if (plansSub) {
      timerCard = findCard(plansSub, '#timersection');
      if (!plansSub.id) plansSub.id = 'sub-plans';
    }

    let ambiCard = null;
    let dispCard = null;
    if (lightSub) {
      ambiCard = findCard(lightSub, 'Ambilight') || findCard(lightSub, 'подсветка');
      dispCard = findCard(lightSub, '#displaysection');
    }

    // Donate from #donatesrc if present
    const donateSrc = document.getElementById('donatesrc');
    let donateFrag = null;
    if (donateSrc) {
      donateFrag = document.createDocumentFragment();
      while (donateSrc.firstChild) donateFrag.appendChild(donateSrc.firstChild);
    }

    // =========================================================================
    // 4. BUILD NEW TARGET SUBTABS:
    // =========================================================================

    // A. SERVICES (Сервисы):
    const servicesSub = document.createElement('div');
    servicesSub.className = 'sub';
    servicesSub.id = 'sub-services';
    servicesSub.dataset.sub = 'services';

    // Group 1: Музыка и стриминг
    servicesSub.appendChild(createGroupHeader('Музыка и стриминг', 'Источники звука и интернет-вещание'));
    if (musicCard) servicesSub.appendChild(musicCard);
    if (accountSub) {
      while (accountSub.firstChild) servicesSub.appendChild(accountSub.firstChild);
    }
    if (netSub) {
      while (netSub.firstChild) servicesSub.appendChild(netSub.firstChild);
    }
    if (airplayCard) servicesSub.appendChild(airplayCard);

    // Group 2: Устройства и интеграции
    servicesSub.appendChild(createGroupHeader('Устройства и интеграции', 'Умный дом, компьютер, телевизор и внешние подключения'));
    const haCard = document.getElementById('mod-ha-section') || findCard(devicesSub, 'Home Assistant') || findCard(settingsTab, 'Home Assistant');
    if (haCard) servicesSub.appendChild(haCard);
    if (tgCard) servicesSub.appendChild(tgCard);
    if (tvCard) servicesSub.appendChild(tvCard);
    if (pcCard) servicesSub.appendChild(pcCard);
    if (btCard) servicesSub.appendChild(btCard);
    settingsTab.appendChild(servicesSub);

    // B. AUTOMATIONS (Автоматизации):
    const autosSub = document.createElement('div');
    autosSub.className = 'sub';
    autosSub.id = 'sub-automations';
    autosSub.dataset.sub = 'automations';

    autosSub.appendChild(createGroupHeader('Будильник и таймеры', 'Расписание пробуждения и рабочие интервалы'));
    if (alarmCard) autosSub.appendChild(alarmCard);
    if (timerCard) autosSub.appendChild(timerCard);

    autosSub.appendChild(createGroupHeader('Сценарии и автозапуск', 'Макросы команд и поведение при старте'));
    if (macroCard) autosSub.appendChild(macroCard);
    if (autoCard) autosSub.appendChild(autoCard);
    settingsTab.appendChild(autosSub);

    // C. SOUND (Звук и голос):
    const soundSub = document.createElement('div');
    soundSub.className = 'sub';
    soundSub.id = 'sub-sound';
    soundSub.dataset.sub = 'sound';

    soundSub.appendChild(createGroupHeader('Акустика и эквалайзер', 'Частоты и звучание треков'));
    if (eqCard) soundSub.appendChild(eqCard);

    soundSub.appendChild(createGroupHeader('Голос и приглушение', 'Громкость Алисы и ducking при вызовах'));
    if (voiceCard) soundSub.appendChild(voiceCard);
    if (duckCard) soundSub.appendChild(duckCard);
    settingsTab.appendChild(soundSub);

    // D. DISPLAY (Экран и вид):
    const displaySub = document.createElement('div');
    displaySub.className = 'sub';
    displaySub.id = 'sub-display';
    displaySub.dataset.sub = 'display';

    // 1. Физическая подсветка на корпусе колонки
    displaySub.appendChild(createGroupHeader('Подсветка колонки', 'Физическая светодиодная матрица на корпусе Станции 2'));

    // Remove clock display section entirely (Station 2 has no digital LED clock screen)
    if (dispCard) dispCard.remove();
    const dispEl = document.getElementById('displaysection');
    if (dispEl) dispEl.remove();

    const lCard = document.createElement('details');
    lCard.className = 'psect soundya-light-card soundya-extracted-card';
    lCard.id = 'sect-speaker-light';
    lCard.open = true;
    lCard.innerHTML = `<summary>Подсветка Станции 2</summary>`;
    if (lightSub) {
      const ds = lightSub.querySelector('#displaysection');
      if (ds) ds.remove();
      lCard.appendChild(lightSub);
    }
    displaySub.appendChild(lCard);

    // 2. Внешний вид страницы (клиентский браузер)
    displaySub.appendChild(createGroupHeader('Внешний вид страницы', 'Оформление, темы и живой фон веб-панели в этом браузере'));
    const lookCard = document.createElement('details');
    lookCard.className = 'psect soundya-extracted-card';
    lookCard.id = 'sect-look';
    lookCard.open = true;
    lookCard.innerHTML = `<summary>Фон и анимации веб-панели</summary>`;
    const lookWrap = document.createElement('div');
    if (lookSub) {
      const topH2 = lookSub.querySelector('h2');
      if (topH2) topH2.remove();
      while (lookSub.firstChild) lookWrap.appendChild(lookSub.firstChild);
    }
    lookCard.appendChild(lookWrap);
    displaySub.appendChild(lookCard);

    settingsTab.appendChild(displaySub);

    // E. SYSTEM (Система):
    const systemSub = document.createElement('div');
    systemSub.className = 'sub';
    systemSub.id = 'sub-system';
    systemSub.dataset.sub = 'system';

    systemSub.appendChild(createGroupHeader('Система soundya', 'Обновления программы, PIN-код и защита ADB'));
    if (aboutSub) {
      while (aboutSub.firstChild) systemSub.appendChild(aboutSub.firstChild);
    }

    systemSub.appendChild(createGroupHeader('Параметры колонки и диагностика', 'Возможности устройства, статистика и сервисные функции'));
    if (donateFrag) systemSub.appendChild(donateFrag);

    // Append remaining speaker content (the catch-all for author updates)
    while (speakerSub.firstChild) {
      systemSub.appendChild(speakerSub.firstChild);
    }
    settingsTab.appendChild(systemSub);

    // Ensure Home Assistant is neatly placed in services even if mounted late:
    const ensureHaPlacement = () => {
      const ha = document.getElementById('mod-ha-section');
      const serv = document.getElementById('sub-services');
      if (ha && serv && ha.parentElement !== serv) {
        const tg = serv.querySelector('#tgsection') || serv.querySelector('#tvsection');
        if (tg) {
          serv.insertBefore(ha, tg);
        } else {
          serv.appendChild(ha);
        }
      }
    };
    setTimeout(ensureHaPlacement, 400);
    setTimeout(ensureHaPlacement, 1200);

    // Hide original empty containers:
    [netSub, accountSub, speakerSub, lookSub, devicesSub, aboutSub].forEach(s => {
      if (s) s.style.display = 'none';
    });

    // 5. Override window.openSettings and window.openSub:
    const origOpenSettings = window.openSettings;
    window.openSettings = function(sub, id) {
      let targetSub = LEGACY_MAP[sub] || sub;
      if (id) {
        const el = document.getElementById(id);
        if (el) {
          const parentSub = el.closest('.sub');
          if (parentSub && parentSub.dataset.sub) {
            targetSub = parentSub.dataset.sub;
          }
        }
      }
      navigateSub(targetSub);
      if (id) {
        setTimeout(() => {
          const el = document.getElementById(id);
          if (el) {
            const d = el.tagName === 'DETAILS' ? el : el.closest('details');
            if (d) d.open = true;
            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
        }, 120);
      }
    };

    const origOpenSub = window.openSub;
    window.openSub = function(name) {
      const mapped = LEGACY_MAP[name] || name;
      navigateSub(mapped);
    };
  }

  function getActiveTab() {
    const activeBtn = document.querySelector('nav button.on');
    if (activeBtn && activeBtn.dataset.tab) return activeBtn.dataset.tab;
    const activeSection = document.querySelector('section.tab.on');
    if (activeSection) return activeSection.id.replace('tab-', '');
    try {
      const saved = localStorage.getItem('tab');
      if (saved) return saved;
    } catch (e) {}
    return 'home';
  }

  function getActiveSub() {
    const activeSub = document.querySelector('#tab-settings .sub.on');
    if (activeSub && activeSub.dataset.sub) return activeSub.dataset.sub;
    try {
      const saved = localStorage.getItem('soundya-sub');
      if (saved) return LEGACY_MAP[saved] || saved;
    } catch (e) {}
    return 'services';
  }

  function navigateMain(tabId) {
    if (tabId === 'glow') {
      const glowBtn = document.querySelector('nav button[data-tab="glow"]');
      if (glowBtn) {
        glowBtn.click();
      } else {
        navigateSub('display');
        return;
      }
    } else if (tabId === 'settings') {
      const activeSub = getActiveSub();
      navigateSub(activeSub);
      return;
    } else {
      if (typeof window.openTab === 'function') {
        window.openTab(tabId);
      } else {
        const btn = document.querySelector(`nav button[data-tab="${tabId}"]`);
        if (btn) btn.click();
      }
    }
    try { window.scrollTo({ top: 0, behavior: 'smooth' }); } catch (e) {}
    syncActiveState();
    closeDrawer();
  }

  function navigateSub(subId) {
    const mapped = LEGACY_MAP[subId] || subId;

    if (typeof window.openTab === 'function') {
      window.openTab('settings');
    } else {
      const settingsBtn = document.querySelector('nav button[data-tab="settings"]');
      if (settingsBtn && !settingsBtn.classList.contains('on')) settingsBtn.click();
    }

    setTimeout(() => {
      // 1. Hide all subtabs
      document.querySelectorAll('#tab-settings .sub').forEach(s => s.classList.remove('on'));

      // 2. Show target subtab
      const targetSub = document.querySelector(`#tab-settings .sub[data-sub="${mapped}"]`);
      if (targetSub) {
        targetSub.classList.add('on');
      }

      // 3. Keep subnav buttons in sync
      document.querySelectorAll('#tab-settings .subnav button').forEach(b => {
        b.classList.toggle('on', b.dataset.sub === mapped);
      });

      // 4. Trigger native loaders if needed
      if (mapped === 'system' || mapped === 'sound') {
        if (typeof window.loadReports === 'function') window.loadReports();
      }
      if (mapped === 'services' || mapped === 'automations') {
        if (typeof window.loadMacros === 'function') window.loadMacros();
      }
      if (mapped === 'mods') {
        if (typeof window.selectModsSub === 'function') window.selectModsSub();
      }

      try { localStorage.setItem('soundya-sub', mapped); } catch (e) {}
      syncActiveState();
    }, 50);

    try { window.scrollTo({ top: 0, behavior: 'smooth' }); } catch (e) {}
    syncActiveState();
    closeDrawer();
  }

  function syncActiveState() {
    const currentTab = getActiveTab();
    const currentSub = getActiveSub();

    // 1. Sync remote button visibility
    const remoteBtn = document.querySelector('nav button[data-tab="remote"]');
    const remoteMenuItem = document.querySelector('.soundya-menu-item[data-tab="remote"]');
    if (remoteMenuItem) {
      if (!remoteBtn || remoteBtn.hasAttribute('hidden') || remoteBtn.hidden) {
        remoteMenuItem.style.display = 'none';
      } else {
        remoteMenuItem.style.display = 'flex';
      }
    }

    // 2. Sync glow (Подсветка) button visibility
    const glowBtn = document.querySelector('nav button[data-tab="glow"]');
    const glowMenuItem = document.querySelector('.soundya-menu-item[data-tab="glow"]');
    if (glowMenuItem) {
      glowMenuItem.style.display = glowBtn ? 'flex' : 'none';
    }

    // 3. Highlight main menu item
    document.querySelectorAll('.soundya-menu-item[data-tab]').forEach(el => {
      const isAct = el.dataset.tab === currentTab;
      el.classList.toggle('active', isAct);
    });

    // 4. Highlight settings submenu item
    document.querySelectorAll('.soundya-submenu-item[data-sub]').forEach(el => {
      const isAct = (currentTab === 'settings') && (el.dataset.sub === currentSub);
      el.classList.toggle('active', isAct);
    });
  }

  function openDrawer() {
    isOpen = true;
    document.body.classList.add('soundya-sidebar-open');
    const burger = document.getElementById('soundya-burger-btn');
    if (burger) burger.classList.add('open');
    syncActiveState();
  }

  function closeDrawer() {
    isOpen = false;
    document.body.classList.remove('soundya-sidebar-open');
    const burger = document.getElementById('soundya-burger-btn');
    if (burger) burger.classList.remove('open');
  }

  function toggleDrawer() {
    if (isOpen) closeDrawer();
    else openDrawer();
  }

  function renderMenuHTML() {
    return `
      <div class="soundya-sidebar-inner">
        <div class="soundya-sidebar-header">
          <div class="soundya-sidebar-brand">
            <span class="soundya-brand-text">sound<span>ya</span></span>
          </div>
          <button type="button" class="soundya-sidebar-close" id="soundya-sidebar-close-btn" aria-label="Закрыть">
            <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2.2" fill="none"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>

        <div class="soundya-sidebar-content">
          <div class="soundya-menu-group">
            <div class="soundya-menu-section-label">Навигация</div>
            <div class="soundya-menu-nav" role="navigation" aria-label="Основное меню">
              ${MAIN_MENU.map(item => `
                <div class="soundya-menu-item-wrap">
                  <button type="button" class="soundya-menu-item" data-tab="${item.id}">
                    <span class="soundya-menu-icon">${item.icon}</span>
                    <span class="soundya-menu-title">${item.title}</span>
                    ${item.id === 'settings' ? '<span class="soundya-menu-arrow" title="Свернуть / развернуть подменю">▾</span>' : ''}
                  </button>

                  ${item.id === 'settings' ? `
                    <div class="soundya-submenu-container" id="soundya-settings-submenu">
                      <div class="soundya-submenu-tree">
                        <div class="soundya-submenu-list">
                          ${SETTINGS_SUBMENU.map(sub => `
                            <button type="button" class="soundya-submenu-item" data-sub="${sub.id}">
                              <span class="soundya-sub-bullet"></span>
                              <span class="soundya-sub-title">${sub.title}</span>
                            </button>
                          `).join('')}
                        </div>
                      </div>
                    </div>
                  ` : ''}
                </div>
              `).join('')}
            </div>
          </div>
        </div>
      </div>
    `;
  }

  function initUI() {
    if (document.getElementById('soundya-sidebar-root')) return;

    document.body.classList.add('soundya-sidebar-installed');

    // Reorganize settings subtabs
    reorganizeSettingsTabs();

    // 1. Root container for left sidebar & mobile drawer
    const root = document.createElement('div');
    root.id = 'soundya-sidebar-root';
    root.innerHTML = `
      <div class="soundya-sidebar-backdrop" id="soundya-sidebar-backdrop"></div>
      <aside class="soundya-sidebar-panel" id="soundya-sidebar-panel" aria-label="Боковое меню">
        ${renderMenuHTML()}
      </aside>
    `;
    document.body.appendChild(root);

    // 2. Burger button placed on the left in header (before h1 logo)
    const burger = document.createElement('button');
    burger.id = 'soundya-burger-btn';
    burger.className = 'soundya-burger-btn';
    burger.type = 'button';
    burger.title = 'Меню навигации';
    burger.setAttribute('aria-label', 'Меню');
    burger.innerHTML = `
      <span class="soundya-burger-box">
        <span class="soundya-burger-line line-1"></span>
        <span class="soundya-burger-line line-2"></span>
        <span class="soundya-burger-line line-3"></span>
      </span>
    `;

    burger.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      toggleDrawer();
    });

    const header = document.querySelector('header');
    const h1 = header ? header.querySelector('h1') : null;
    if (header && h1) {
      header.insertBefore(burger, h1);
    } else if (header) {
      header.prepend(burger);
    } else {
      document.body.appendChild(burger);
    }

    // 3. Bind close events
    const closeBtn = document.getElementById('soundya-sidebar-close-btn');
    if (closeBtn) closeBtn.onclick = () => closeDrawer();

    const backdrop = document.getElementById('soundya-sidebar-backdrop');
    if (backdrop) backdrop.onclick = () => closeDrawer();

    // 4. Bind navigation clicks
    root.querySelectorAll('.soundya-menu-item[data-tab]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        // If clicking on chevron arrow of settings, toggle submenu accordion
        if (e.target && e.target.classList.contains('soundya-menu-arrow')) {
          e.preventDefault();
          e.stopPropagation();
          const sub = document.getElementById('soundya-settings-submenu');
          if (sub) sub.classList.toggle('collapsed');
          return;
        }

        e.preventDefault();
        navigateMain(btn.dataset.tab);
      });
    });

    root.querySelectorAll('.soundya-submenu-item[data-sub]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        navigateSub(btn.dataset.sub);
      });
    });

    // 5. Escape key listener
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && isOpen) closeDrawer();
    });

    // 6. Dynamic DOM observer: sync whenever tabs or classes change
    observer = new MutationObserver(() => {
      syncActiveState();
    });

    const nav = document.querySelector('main > nav') || document.querySelector('nav');
    if (nav) observer.observe(nav, { attributes: true, subtree: true, childList: true });
    const settingsTab = document.getElementById('tab-settings');
    if (settingsTab) observer.observe(settingsTab, { attributes: true, subtree: true, childList: true });
    observer.observe(document.body, { attributes: true, attributeFilter: ['class'] });

    // Initial activation:
    const currentTab = getActiveTab();
    const activeSub = getActiveSub();
    if (currentTab === 'settings') {
      navigateSub(activeSub);
    } else {
      document.querySelectorAll('#tab-settings .sub').forEach(s => s.classList.remove('on'));
      const targetSub = document.querySelector(`#tab-settings .sub[data-sub="${activeSub}"]`);
      if (targetSub) targetSub.classList.add('on');
    }

    setTimeout(syncActiveState, 50);
    setTimeout(syncActiveState, 300);
    setTimeout(syncActiveState, 1000);
  }

  window.openSoundyaSidebar = openDrawer;
  window.closeSoundyaSidebar = closeDrawer;
  window.toggleSoundyaSidebar = toggleDrawer;

  window.destroyMod_sidebar = function() {
    if (observer) observer.disconnect();
    const root = document.getElementById('soundya-sidebar-root');
    if (root) root.remove();
    const burger = document.getElementById('soundya-burger-btn');
    if (burger) burger.remove();
    document.body.classList.remove('soundya-sidebar-open', 'soundya-sidebar-installed');
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initUI);
  } else {
    initUI();
  }
})();
