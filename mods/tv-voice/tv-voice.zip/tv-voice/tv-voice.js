// Модуль «Управление ТВ и проектором: голосовые фразы и настройки поиска»
(function() {
  const MOD_ID = 'tv-voice';
  const CONFIG_KEY = 'soundya-tv-voice-cfg';

  // Известные красивые названия популярных приложений
  const KNOWN_LABELS = {
    'org.smarttube.stable': 'SmartTube',
    'com.teamsmart.videomanager.tv': 'SmartTube Next',
    'com.google.android.youtube.tv': 'YouTube',
    'youtube.tv.unplugged': 'YouTube Music',
    'top.rootu.bylumpa': 'Lampa (Bylumpa)',
    'top.rootu.lamps': 'Lampa (Lamps)',
    'ru.kinopoisk.tv': 'Кинопоиск',
    'ru.yourok.num': 'NUM (No UI Movies)',
    'ru.yourok.torrserve': 'TorrServe',
    'com.swiftsoft.viewbox': 'ViewBox',
    'com.stremio.one': 'Stremio',
    'org.xbmc.kodi': 'Kodi',
    'ru.ivi.client': 'Иви (ivi)',
    'tv.okko.androidtv': 'Okko',
    'ru.rt.video': 'Wink',
    'com.mts.mtstv': 'KION',
    'com.spotify.tv.android': 'Spotify',
    'net.mullvad.mullvadvpn': 'Mullvad VPN',
    'net.gtvbox.videoplayer': 'Vimu Media Player',
    'com.mxtech.videoplayer.television': 'MX Player',
    'com.cxinventor.file.explorer': 'CX Проводник',
    'ca.dstudio.atvlauncher.free': 'ATV Launcher',
    'cm.aptoidetv.pt': 'Aptoide TV',
    'dev.projectivy.blueprint.app': 'Projectivy Launcher',
    'dev.vodik7.tvquickactions': 'tvQuickActions',
    'org.liskovsoft.androidtv.rukeyboard': 'RuKeyboard (Leanback IME)'
  };

  // Конфигурация для каждого ТВ: { _common: { input_triggers }, [tvKey]: { youtube_pkg, movie_pkg, apps, names } }
  let multiTvConfig = {
    _common: {
      input_triggers: 'введи, напечатай, вбей, напиши'
    },
    main: {
      youtube_pkg: 'org.smarttube.stable',
      movie_pkg: 'top.rootu.bylumpa',
      apps: [],
      names: {}
    }
  };

  function loadSavedConfig() {
    try {
      const saved = localStorage.getItem(CONFIG_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.youtube_pkg && !parsed.main) {
          multiTvConfig.main = {
            youtube_pkg: parsed.youtube_pkg,
            movie_pkg: parsed.movie_pkg,
            apps: parsed.apps || [],
            names: parsed.names || {}
          };
          if (parsed.input_triggers) multiTvConfig._common.input_triggers = parsed.input_triggers;
        } else {
          multiTvConfig = Object.assign({}, multiTvConfig, parsed);
        }
      }
    } catch (e) {}
  }

  function saveConfig() {
    try {
      localStorage.setItem(CONFIG_KEY, JSON.stringify(multiTvConfig));
    } catch (e) {}
  }

  function getTvSettings(tvKey) {
    if (!multiTvConfig[tvKey]) {
      multiTvConfig[tvKey] = {
        youtube_pkg: (multiTvConfig.main && multiTvConfig.main.youtube_pkg) ? multiTvConfig.main.youtube_pkg : 'org.smarttube.stable',
        movie_pkg: (multiTvConfig.main && multiTvConfig.main.movie_pkg) ? multiTvConfig.main.movie_pkg : 'top.rootu.bylumpa',
        apps: [],
        names: {}
      };
    }
    return multiTvConfig[tvKey];
  }

  function getCleanLabel(pkg, rawName) {
    if (KNOWN_LABELS[pkg]) return KNOWN_LABELS[pkg];
    if (!rawName) return pkg;
    let clean = rawName.replace(`(${pkg})`, '').trim();
    return clean || pkg;
  }

  function isYoutubeApp(pkg, label) {
    const pl = pkg.toLowerCase();
    const ll = (label || '').toLowerCase();
    return pl.includes('youtube') || pl.includes('smarttube') || ll.includes('ютуб') || ll.includes('smarttube');
  }

  function isMovieApp(pkg, label) {
    const pl = pkg.toLowerCase();
    const ll = (label || '').toLowerCase();
    return ['lampa', 'lumpa', 'kinopoisk', 'кинопоиск', 'num', 'viewbox', 'stremio', 'kodi', 'ivi', 'okko', 'wink', 'kion', 'premier', 'amediateka', 'torrserve']
      .some(k => pl.includes(k) || ll.includes(k));
  }

  async function postCmd(cmd) {
    const res = await fetch('/api/cmd', {
      method: 'POST',
      body: cmd
    });
    return await res.text();
  }

  // Применение макросов на колонке при сохранении настроек
  async function syncMacrosToSpeaker() {
    try {
      // 1. Основной ТВ
      const mainCfg = getTvSettings('main');
      if (mainCfg.youtube_pkg) {
        await postCmd(`macro add открой ютуб ||| tv openpkg ${mainCfg.youtube_pkg}`);
        await postCmd(`macro add включи ютуб ||| tv openpkg ${mainCfg.youtube_pkg}`);
        await postCmd(`macro add ютуб ||| tv openpkg ${mainCfg.youtube_pkg}`);
      }
      if (mainCfg.movie_pkg) {
        await postCmd(`macro add открой кино ||| tv openpkg ${mainCfg.movie_pkg}`);
        await postCmd(`macro add включи кино ||| tv openpkg ${mainCfg.movie_pkg}`);
        await postCmd(`macro add открой фильм ||| tv openpkg ${mainCfg.movie_pkg}`);
        await postCmd(`macro add включи фильм ||| tv openpkg ${mainCfg.movie_pkg}`);
        await postCmd(`macro add кино ||| tv openpkg ${mainCfg.movie_pkg}`);
        await postCmd(`macro add фильмы ||| tv openpkg ${mainCfg.movie_pkg}`);
        await postCmd(`macro add лампа ||| tv openpkg ${mainCfg.movie_pkg}`);
      }

      // 2. Дополнительные ТВ из списка #tvsmore
      document.querySelectorAll('#tvsmore .devrow').forEach(async (row, idx) => {
        const nameInput = row.querySelector('.dname');
        const name = nameInput ? nameInput.value.trim() : '';
        const tvKey = row.dataset.tvVoiceKey || ('tv_row_' + idx);
        if (!name) return;

        const cfg = getTvSettings(tvKey);
        if (cfg.youtube_pkg) {
          await postCmd(`macro add открой ютуб в ${name} ||| on ${name}\ttv openpkg ${cfg.youtube_pkg}`);
          await postCmd(`macro add включи ютуб в ${name} ||| on ${name}\ttv openpkg ${cfg.youtube_pkg}`);
          await postCmd(`macro add открой ютуб на ${name} ||| on ${name}\ttv openpkg ${cfg.youtube_pkg}`);
          await postCmd(`macro add включи ютуб на ${name} ||| on ${name}\ttv openpkg ${cfg.youtube_pkg}`);
        }
        if (cfg.movie_pkg) {
          await postCmd(`macro add открой кино в ${name} ||| on ${name}\ttv openpkg ${cfg.movie_pkg}`);
          await postCmd(`macro add включи кино в ${name} ||| on ${name}\ttv openpkg ${cfg.movie_pkg}`);
          await postCmd(`macro add открой фильм в ${name} ||| on ${name}\ttv openpkg ${cfg.movie_pkg}`);
          await postCmd(`macro add включи фильм в ${name} ||| on ${name}\ttv openpkg ${cfg.movie_pkg}`);
          await postCmd(`macro add кино в ${name} ||| on ${name}\ttv openpkg ${cfg.movie_pkg}`);
          await postCmd(`macro add лампа в ${name} ||| on ${name}\ttv openpkg ${cfg.movie_pkg}`);
          await postCmd(`macro add открой кино на ${name} ||| on ${name}\ttv openpkg ${cfg.movie_pkg}`);
          await postCmd(`macro add включи кино на ${name} ||| on ${name}\ttv openpkg ${cfg.movie_pkg}`);
          await postCmd(`macro add лампа на ${name} ||| on ${name}\ttv openpkg ${cfg.movie_pkg}`);
        }
      });

      saveConfig();
    } catch (err) {
      console.warn('tv-voice macro sync error:', err);
    }
  }

  function hookNativeSaveButton() {
    const nativeBtn = document.getElementById('tvtestbtn');
    if (nativeBtn && !nativeBtn.dataset.tvVoiceHooked) {
      nativeBtn.dataset.tvVoiceHooked = 'true';
      nativeBtn.addEventListener('click', () => {
        syncMacrosToSpeaker();
      });
    }
  }

  // Запрос приложений с ТВ (поддерживает как основной, так и именованный ТВ)
  async function fetchAppsForTv(tvKey, targetTvName, btnEl) {
    const msg = document.getElementById('tvmsg');
    const tvCfg = getTvSettings(tvKey);
    const displayName = targetTvName || 'телевизора';

    if (btnEl) btnEl.disabled = true;
    if (msg) {
      msg.textContent = `Запрашиваю приложения с «${displayName}»…`;
      msg.className = 'msg on';
    }

    try {
      const cmd = targetTvName ? `on ${targetTvName}\ttv apps` : 'tv apps';
      const res = await fetch('/api/cmd', { method: 'POST', body: cmd });
      const text = await res.text();
      let data = null;
      try {
        data = JSON.parse(text);
      } catch (e) {
        try {
          data = JSON.parse(text.replace(/^OK:\s*/, ''));
        } catch (e2) {}
      }

      let appList = [];
      let appNames = {};

      if (data) {
        if (Array.isArray(data.apps)) {
          appList = data.apps;
          appNames = data.names || {};
        } else if (Array.isArray(data.packages)) {
          appList = data.packages;
          appNames = data.names || {};
        } else if (Array.isArray(data)) {
          appList = data;
        }
      }

      if (appList.length > 0) {
        tvCfg.apps = appList;
        tvCfg.names = appNames;

        const hasSmartTube = appList.find(p => p.includes('smarttube'));
        const hasYouTube = appList.find(p => p.includes('youtube'));
        if (hasSmartTube) {
          tvCfg.youtube_pkg = hasSmartTube;
        } else if (hasYouTube) {
          tvCfg.youtube_pkg = hasYouTube;
        }

        const hasLampa = appList.find(p => p.includes('bylumpa') || p.includes('lamps') || p.includes('lampa'));
        const hasKinopoisk = appList.find(p => p.includes('kinopoisk'));
        const hasNum = appList.find(p => p.includes('num'));
        if (hasLampa) {
          tvCfg.movie_pkg = hasLampa;
        } else if (hasKinopoisk) {
          tvCfg.movie_pkg = hasKinopoisk;
        } else if (hasNum) {
          tvCfg.movie_pkg = hasNum;
        }

        saveConfig();
        renderTvAppBox(tvKey);

        if (msg) {
          msg.textContent = `Получено приложений с «${displayName}»: ${appList.length}. Нажмите «Сохранить и подключить» ниже.`;
          msg.className = 'msg on ok';
        }
      } else {
        if (msg) {
          msg.textContent = text.startsWith('error') ? text : 'Телевизор ответил: ' + text;
          msg.className = 'msg on err';
        }
      }
    } catch (e) {
      if (msg) {
        msg.textContent = 'Ошибка связи с ТВ: ' + e.message;
        msg.className = 'msg on err';
      }
    } finally {
      if (btnEl) btnEl.disabled = false;
    }
  }

  // Генерация HTML <option> с группировкой ⭐ Рекомендуемые
  function buildOptionsHtml(apps, names, filterFn, currentVal) {
    if (!apps || apps.length === 0) {
      return `<option value="">(нажмите «Запросить приложения с ТВ» или введите имя пакета)</option>`;
    }

    const recApps = [];
    const otherApps = [];

    apps.forEach(pkg => {
      const label = getCleanLabel(pkg, names[pkg]);
      const item = { pkg, label };
      if (filterFn(pkg, label)) {
        recApps.push(item);
      } else {
        otherApps.push(item);
      }
    });

    recApps.sort((a, b) => a.label.localeCompare(b.label, 'ru'));
    otherApps.sort((a, b) => a.label.localeCompare(b.label, 'ru'));

    let html = `<option value="">(выберите из списка)</option>`;

    if (recApps.length > 0) {
      html += `<optgroup label="⭐ Рекомендуемые приложения">`;
      recApps.forEach(item => {
        const isSel = (item.pkg === currentVal) ? 'selected' : '';
        html += `<option value="${item.pkg}" ${isSel}>⭐ ${item.label} (${item.pkg})</option>`;
      });
      html += `</optgroup>`;
    }

    if (otherApps.length > 0) {
      html += `<optgroup label="Все остальные приложения ТВ">`;
      otherApps.forEach(item => {
        const isSel = (item.pkg === currentVal) ? 'selected' : '';
        html += `<option value="${item.pkg}" ${isSel}>${item.label} (${item.pkg})</option>`;
      });
      html += `</optgroup>`;
    }

    return html;
  }

  // Отрисовка или обновление полей конкретного блока приложений
  function renderTvAppBox(tvKey, containerEl) {
    const box = containerEl || document.getElementById(`tv-voice-box-${tvKey}`);
    if (!box) return;

    const tvCfg = getTvSettings(tvKey);
    const ytSel = box.querySelector('.tv-yt-sel');
    const ytInput = box.querySelector('.tv-yt-pkg');
    const mvSel = box.querySelector('.tv-mv-sel');
    const mvInput = box.querySelector('.tv-mv-pkg');

    if (ytSel) ytSel.innerHTML = buildOptionsHtml(tvCfg.apps, tvCfg.names, isYoutubeApp, tvCfg.youtube_pkg);
    if (ytInput) ytInput.value = tvCfg.youtube_pkg || '';
    if (mvSel) mvSel.innerHTML = buildOptionsHtml(tvCfg.apps, tvCfg.names, isMovieApp, tvCfg.movie_pkg);
    if (mvInput) mvInput.value = tvCfg.movie_pkg || '';
  }

  // Создание разметки блока выбора приложений для любого ТВ
  function createTvAppBlockHtml(tvKey, titleText) {
    const tvCfg = getTvSettings(tvKey);
    return `
      <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; margin-bottom:10px;">
        <span style="font-size:13px; font-weight:600; color:var(--ink);">${titleText}</span>
        <button type="button" class="sm tv-fetch-btn" style="padding:4px 10px; font-size:12px;">Запросить приложения с ТВ</button>
      </div>

      <label class="tv-voice-field">
        <span class="label">Приложение для YouTube</span>
        <select class="tv-yt-sel"></select>
        <input type="text" class="tv-yt-pkg" value="${tvCfg.youtube_pkg || ''}" placeholder="org.smarttube.stable или com.google.android.youtube.tv" autocomplete="off" spellcheck="false">
        <span class="hint">Пакет для фраз «включи ютуб», «открой ютуб». Для SmartTube: <code>org.smarttube.stable</code>.</span>
      </label>

      <label class="tv-voice-field">
        <span class="label">Приложение для фильмов и сериалов</span>
        <select class="tv-mv-sel"></select>
        <input type="text" class="tv-mv-pkg" value="${tvCfg.movie_pkg || ''}" placeholder="top.rootu.bylumpa, ru.kinopoisk.tv, ru.yourok.num..." autocomplete="off" spellcheck="false">
        <span class="hint">Пакет для фраз «открой кино», «найди фильм» (Lampa, Кинопоиск, NUM).</span>
      </label>
    `;
  }

  function bindTvBlockEvents(block, tvKey, getTargetTvName) {
    const ytSel = block.querySelector('.tv-yt-sel');
    const ytInput = block.querySelector('.tv-yt-pkg');
    const mvSel = block.querySelector('.tv-mv-sel');
    const mvInput = block.querySelector('.tv-mv-pkg');
    const fetchBtn = block.querySelector('.tv-fetch-btn');

    if (ytSel) {
      ytSel.onchange = function() {
        if (this.value) {
          if (ytInput) ytInput.value = this.value;
          const cfg = getTvSettings(tvKey);
          cfg.youtube_pkg = this.value;
          saveConfig();
        }
      };
    }
    if (ytInput) {
      ytInput.oninput = function() {
        const cfg = getTvSettings(tvKey);
        cfg.youtube_pkg = this.value.trim();
        saveConfig();
      };
    }

    if (mvSel) {
      mvSel.onchange = function() {
        if (this.value) {
          if (mvInput) mvInput.value = this.value;
          const cfg = getTvSettings(tvKey);
          cfg.movie_pkg = this.value;
          saveConfig();
        }
      };
    }
    if (mvInput) {
      mvInput.oninput = function() {
        const cfg = getTvSettings(tvKey);
        cfg.movie_pkg = this.value.trim();
        saveConfig();
      };
    }

    if (fetchBtn) {
      fetchBtn.onclick = function() {
        const tvName = getTargetTvName ? getTargetTvName() : '';
        fetchAppsForTv(tvKey, tvName, fetchBtn);
      };
    }
  }

  // Главная функция инжекции и синхронизации блоков приложений
  function injectAllTvBoxes() {
    const tvSection = document.getElementById('tvsection');
    if (!tvSection) return;

    loadSavedConfig();
    hookNativeSaveButton();

    // 1. Блок для ОСНОВНОГО телевизора
    if (!document.getElementById('tv-voice-box-main')) {
      const mainBox = document.createElement('div');
      mainBox.id = 'tv-voice-box-main';
      mainBox.className = 'tv-voice-panel';
      mainBox.innerHTML = `
        <h3 style="margin-bottom:12px;">Приложения основного ТВ (голосовой поиск и запуск)</h3>
        ${createTvAppBlockHtml('main', 'Голосовые приложения основного ТВ')}
        
        <label class="tv-voice-field" style="margin-top:14px; border-top:1px solid var(--line); padding-top:12px;">
          <span class="label">Активирующие слова для ввода текста на ТВ (AdbIME / input text)</span>
          <input type="text" id="tv-voice-input-triggers" value="${multiTvConfig._common.input_triggers}" placeholder="введи, напечатай, вбей, напиши" autocomplete="off" spellcheck="false">
          <span class="hint">Фразы, после которых колонка печатает текст в активное поле на экране ТВ (например: <code>введи</code>).</span>
        </label>
      `;

      // Размещаем блок основного ТВ сразу после его поля адреса tvhost
      const hostInput = document.getElementById('tvhost');
      const targetParent = hostInput ? hostInput.closest('label') : tvSection.nextElementSibling;
      if (targetParent && targetParent.parentNode) {
        targetParent.parentNode.insertBefore(mainBox, targetParent.nextSibling);
      } else {
        tvSection.parentNode.insertBefore(mainBox, tvSection.nextSibling);
      }

      bindTvBlockEvents(mainBox, 'main', () => {
        const nameInput = document.getElementById('tvname');
        return nameInput ? nameInput.value.trim() : '';
      });

      const triggersInput = document.getElementById('tv-voice-input-triggers');
      if (triggersInput) {
        triggersInput.oninput = function() {
          multiTvConfig._common.input_triggers = this.value.trim();
          saveConfig();
        };
      }

      renderTvAppBox('main', mainBox);
    }

    // 2. Блоки для КАЖДОГО ДОБАВЛЕННОГО телевизора в #tvsmore
    const tvsMoreBox = document.getElementById('tvsmore');
    if (tvsMoreBox) {
      tvsMoreBox.querySelectorAll('.devrow').forEach((row, idx) => {
        // Каждой строке телевизора привязываем уникальный ключ
        let tvKey = row.dataset.tvVoiceKey;
        if (!tvKey) {
          const nameInput = row.querySelector('.dname');
          const nameVal = nameInput ? nameInput.value.trim() : '';
          tvKey = nameVal ? `tv_${nameVal}` : `tv_row_${Date.now()}_${idx}`;
          row.dataset.tvVoiceKey = tvKey;
        }

        const boxId = `tv-voice-box-${tvKey}`;
        let subBox = row.querySelector(`#${boxId}`);
        if (!subBox) {
          subBox = document.createElement('div');
          subBox.id = boxId;
          subBox.className = 'tv-voice-subpanel';
          subBox.style.width = '100%';
          subBox.innerHTML = createTvAppBlockHtml(tvKey, 'Приложения для этого ТВ');
          row.appendChild(subBox);

          bindTvBlockEvents(subBox, tvKey, () => {
            const nameInput = row.querySelector('.dname');
            return nameInput ? nameInput.value.trim() : '';
          });

          renderTvAppBox(tvKey, subBox);
        }
      });
    }

    // 3. Блок-подсказка с командами
    if (!document.getElementById('tv-voice-helper-card')) {
      const helperCard = document.createElement('details');
      helperCard.id = 'tv-voice-helper-card';
      helperCard.className = 'guide';
      helperCard.open = true;
      helperCard.innerHTML = `
        <summary>Расширенные команды — кино, YouTube и ввод текста</summary>
        <table class="cmds">
          <tbody>
            <tr>
              <td>«Алиса, включи (выключи) телевизор / проектор»</td>
              <td>Включение экрана (WOL/ADB) или перевод телевизора / проектора в режим сна</td>
            </tr>
            <tr>
              <td>«Алиса, открой ютуб на проекторе»</td>
              <td>Запуск настроенного приложения YouTube или SmartTube (на конкретном устройстве: «на кухне», «в спальне»)</td>
            </tr>
            <tr>
              <td>«Алиса, найди на ютубе [видео]»</td>
              <td>Прямой поиск и запуск ролика на YouTube</td>
            </tr>
            <tr>
              <td>«Алиса, открой кино / фильм»</td>
              <td>Запуск настроенного онлайн-кинотеатра (Lampa, Кинопоиск, NUM и др.)</td>
            </tr>
            <tr>
              <td>«Алиса, найди фильм [название]»</td>
              <td>Глобальный поиск фильма или открытие карточки в кинотеатре</td>
            </tr>
            <tr>
              <td>«Алиса, введи [текст] на телевизоре»</td>
              <td>Печать текста в активное поле ввода (через AdbIME / input text)</td>
            </tr>
            <tr>
              <td>«Алиса, пауза / громче / тише на телевизоре»</td>
              <td>Управление воспроизведением и громкостью Android TV</td>
            </tr>
          </tbody>
        </table>
      `;

      const tvTestBtn = document.getElementById('tvtestbtn');
      const insertTarget = tvTestBtn ? tvTestBtn.closest('.row') : null;
      if (insertTarget && insertTarget.parentNode) {
        insertTarget.parentNode.insertBefore(helperCard, insertTarget.nextSibling);
      }
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectAllTvBoxes);
  } else {
    injectAllTvBoxes();
  }

  window.addEventListener('load', injectAllTvBoxes);
  // Наблюдатель за добавлением новых строк телевизоров в #tvsmore
  setInterval(injectAllTvBoxes, 1200);

  window.destroyMod_tv_voice = function() {
    const mainBox = document.getElementById('tv-voice-box-main');
    if (mainBox) mainBox.remove();
    document.querySelectorAll('.tv-voice-subpanel').forEach(el => el.remove());
    const guide = document.getElementById('tv-voice-helper-card');
    if (guide) guide.remove();
  };
})();
