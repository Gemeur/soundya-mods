/**
 * Soundya Docked Bottom Player Mod
 * Pinned Floating Glass Pill Player & Enhanced Smooth Search
 */
(function initDockPlayer() {
  if (window.__soundyaDockPlayerInit) return;
  window.__soundyaDockPlayerInit = true;

  function setup() {
    const player = document.querySelector('section.player');
    if (!player) return false;
    if (player.classList.contains('soundya-docked-player')) return true;

    // 1. Mark body and player
    document.body.classList.add('has-docked-player');
    player.classList.add('soundya-docked-player');

    // 2. Locate elements inside player
    const psearchbtn = document.getElementById('psearchbtn');
    const psearch = document.getElementById('psearch');
    const query = document.getElementById('query');
    const searchmsg = document.getElementById('searchmsg');
    const results = document.getElementById('results');
    const now = player.querySelector('.now');
    const cover = document.getElementById('cover');
    const track = document.getElementById('track');
    const seek = document.getElementById('seek');
    const times = player.querySelector('.times');
    const pos = document.getElementById('pos');
    const dur = document.getElementById('dur');
    const controls = player.querySelector('.controls:not(.small)');
    const controlsSmall = player.querySelector('.controls.small');
    const shufflebtn = document.getElementById('shufflebtn');
    const repeatbtn = document.getElementById('repeatbtn');
    const likebtn = document.getElementById('likebtn');
    const plbtn = document.getElementById('plbtn');
    const volbtn = document.getElementById('volbtn');
    const volpop = document.getElementById('volpop');
    const qwrap = document.getElementById('qwrap');
    const qbtn = document.getElementById('qbtn');
    const openbtn = document.getElementById('openbtn');
    const picker = document.getElementById('picker');
    const actmsg = document.getElementById('actmsg');
    const listennote = document.getElementById('listennote');
    const listenaudio = document.getElementById('listenaudio');

    // Extract action buttons from controls:
    let prevBtn = player.querySelector('button[onclick*="prev"]');
    let toggleBtn = document.getElementById('toggle') || player.querySelector('button[onclick*="toggle"]');
    let nextBtn = player.querySelector('button[onclick*="next"]');
    let stopBtn = player.querySelector('button[onclick*="stop"]');

    // Extract similar button from controlsSmall:
    let similarBtn = player.querySelector('button[onclick*="similar"]');

    // Enhance Search Panel (#psearch)
    if (psearch) {
      psearch.className = 'soundya-dock-search';

      if (!psearch.querySelector('.soundya-search-head')) {
        const head = document.createElement('div');
        head.className = 'soundya-search-head';
        head.innerHTML = `
          <div class="soundya-search-title">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/></svg>
            <span>Поиск треков на SoundCloud</span>
          </div>
          <button type="button" class="soundya-search-close" id="psearchCloseBtn" title="Закрыть" aria-label="Закрыть">×</button>
        `;
        psearch.prepend(head);

        const closeBtn = head.querySelector('#psearchCloseBtn');
        if (closeBtn) {
          closeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (typeof closeSearch === 'function') {
              closeSearch();
            } else {
              psearch.hidden = true;
              if (psearchbtn) {
                psearchbtn.classList.remove('on');
                psearchbtn.setAttribute('aria-expanded', 'false');
              }
            }
          });
        }
      }

      const oldSearchRow = psearch.querySelector('.search');
      if (oldSearchRow && !oldSearchRow.classList.contains('soundya-search-bar')) {
        oldSearchRow.className = 'soundya-search-bar';
        if (query) {
          const wrap = document.createElement('div');
          wrap.className = 'soundya-search-input-wrap';
          query.parentNode.insertBefore(wrap, query);

          const icon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
          icon.setAttribute('class', 'soundya-search-icon');
          icon.setAttribute('viewBox', '0 0 24 24');
          icon.setAttribute('fill', 'none');
          icon.setAttribute('stroke', 'currentColor');
          icon.setAttribute('stroke-width', '2.2');
          icon.setAttribute('stroke-linecap', 'round');
          icon.innerHTML = '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>';

          const clearBtn = document.createElement('button');
          clearBtn.type = 'button';
          clearBtn.id = 'psearchClearBtn';
          clearBtn.className = 'soundya-search-clear';
          clearBtn.title = 'Очистить';
          clearBtn.textContent = '✕';
          clearBtn.style.display = query.value ? 'inline-flex' : 'none';

          wrap.appendChild(icon);
          wrap.appendChild(query);
          wrap.appendChild(clearBtn);

          query.addEventListener('input', () => {
            clearBtn.style.display = query.value ? 'inline-flex' : 'none';
          });

          clearBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            query.value = '';
            clearBtn.style.display = 'none';
            if (results) results.innerHTML = '';
            if (searchmsg) searchmsg.textContent = '';
            query.focus();
          });
        }

        const submitBtn = oldSearchRow.querySelector('button.primary');
        if (submitBtn) {
          submitBtn.classList.add('soundya-search-submit');
        }
      }

      if (results) {
        results.classList.add('soundya-search-results');
      }
    }

    // --- ROW 1: TOP ROW (LEFT, CENTER, RIGHT) ---
    const dockTop = document.createElement('div');
    dockTop.className = 'soundya-dock-top';

    // LEFT: Cover + Track info + Like
    const dockLeft = document.createElement('div');
    dockLeft.className = 'soundya-dock-left';

    const coverWrap = document.createElement('div');
    coverWrap.className = 'cover-wrapper';
    coverWrap.id = 'coverWrapper';
    coverWrap.title = 'Открыть на SoundCloud';
    coverWrap.addEventListener('click', () => {
      if (typeof openCurrent === 'function') openCurrent();
    });
    if (cover) coverWrap.appendChild(cover);
    dockLeft.appendChild(coverWrap);

    const trackMeta = document.createElement('div');
    trackMeta.className = 'soundya-track-meta';
    const trackTitleWrap = document.createElement('div');
    trackTitleWrap.className = 'soundya-track-title';
    if (track) trackTitleWrap.appendChild(track);
    trackMeta.appendChild(trackTitleWrap);
    dockLeft.appendChild(trackMeta);

    if (likebtn) {
      likebtn.classList.add('icon', 'soundya-icon-btn', 'heart-btn');
      dockLeft.appendChild(likebtn);
    }

    // CENTER: Controls
    const dockCenter = document.createElement('div');
    dockCenter.className = 'soundya-dock-center';

    if (shufflebtn) {
      shufflebtn.classList.add('icon', 'soundya-icon-btn');
      dockCenter.appendChild(shufflebtn);
    }
    if (prevBtn) {
      prevBtn.classList.add('icon', 'soundya-icon-btn');
      dockCenter.appendChild(prevBtn);
    }
    if (toggleBtn) {
      toggleBtn.classList.add('icon', 'toggle-btn');
      dockCenter.appendChild(toggleBtn);
    }
    if (nextBtn) {
      nextBtn.classList.add('icon', 'soundya-icon-btn');
      dockCenter.appendChild(nextBtn);
    }
    if (repeatbtn) {
      repeatbtn.classList.add('icon', 'soundya-icon-btn');
      dockCenter.appendChild(repeatbtn);
    }

    // RIGHT: Utilities
    const dockRight = document.createElement('div');
    dockRight.className = 'soundya-dock-right';

    if (psearchbtn) {
      psearchbtn.classList.add('icon', 'soundya-icon-btn', 'psearchbtn');
      dockRight.appendChild(psearchbtn);
    }
    if (qwrap) {
      dockRight.appendChild(qwrap);
      if (qbtn) qbtn.classList.add('icon', 'soundya-icon-btn');
    }
    if (similarBtn) {
      similarBtn.classList.add('icon', 'soundya-icon-btn');
      dockRight.appendChild(similarBtn);
    }
    if (plbtn) {
      plbtn.classList.add('icon', 'soundya-icon-btn');
      dockRight.appendChild(plbtn);
    }
    if (openbtn) {
      openbtn.classList.add('icon', 'soundya-icon-btn');
      dockRight.appendChild(openbtn);
    }
    if (volbtn) {
      volbtn.classList.add('icon', 'soundya-icon-btn');
      dockRight.appendChild(volbtn);
    }
    if (stopBtn) {
      stopBtn.classList.add('icon', 'soundya-icon-btn', 'soundya-stop-btn');
      dockRight.appendChild(stopBtn);
    }

    // Close Player Button (replaces minimize)
    const closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.id = 'dockCloseBtn';
    closeBtn.className = 'icon soundya-icon-btn soundya-close-btn';
    closeBtn.title = 'Закрыть плеер';
    closeBtn.setAttribute('aria-label', 'Закрыть плеер');
    closeBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
    dockRight.appendChild(closeBtn);

    dockTop.appendChild(dockLeft);
    dockTop.appendChild(dockCenter);
    dockTop.appendChild(dockRight);

    // --- ROW 2: BOTTOM ROW (TIMELINE & TIMESTAMPS) ---
    const dockBottom = document.createElement('div');
    dockBottom.className = 'soundya-dock-bottom';
    if (pos) dockBottom.appendChild(pos);
    if (seek) dockBottom.appendChild(seek);
    if (dur) dockBottom.appendChild(dur);

    // Reassemble inside player
    player.innerHTML = '';
    if (psearch) player.appendChild(psearch);
    player.appendChild(dockTop);
    player.appendChild(dockBottom);
    if (volpop) player.appendChild(volpop);
    if (picker) player.appendChild(picker);
    if (actmsg) player.appendChild(actmsg);
    if (listennote) player.appendChild(listennote);
    if (listenaudio) player.appendChild(listenaudio);

    // Clean up empty containers
    if (now && now.parentNode) now.remove();
    if (times && times.parentNode) times.remove();
    if (controls && controls.parentNode) controls.remove();
    if (controlsSmall && controlsSmall.parentNode) controlsSmall.remove();

    // Floating restore pill if user wants to bring player back
    let restoreBtn = document.getElementById('dockRestoreBtn');
    if (!restoreBtn) {
      restoreBtn = document.createElement('button');
      restoreBtn.id = 'dockRestoreBtn';
      restoreBtn.className = 'soundya-dock-restore';
      restoreBtn.title = 'Открыть плеер';
      restoreBtn.setAttribute('aria-label', 'Открыть плеер');
      restoreBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8" fill="currentColor"/></svg><span>Плеер</span>';
      restoreBtn.hidden = true;
      document.body.appendChild(restoreBtn);

      restoreBtn.addEventListener('click', () => {
        openPlayer();
      });
    }

    function closePlayer() {
      // 1. Stop music
      if (typeof cmd === 'function') {
        cmd('stop');
      } else {
        try { fetch('/api/cmd', { method: 'POST', body: 'stop' }); } catch (e) {}
      }

      // 2. Close any open popovers
      if (typeof closeSearch === 'function') closeSearch();
      else if (psearch) psearch.hidden = true;
      if (volpop) volpop.hidden = true;
      if (picker) picker.style.display = 'none';

      // 3. Hide player and adjust body
      player.classList.add('closed');
      document.body.classList.remove('has-docked-player');
      restoreBtn.hidden = false;
      try { localStorage.setItem('soundya_dock_closed', '1'); } catch (e) {}
    }

    function openPlayer() {
      player.classList.remove('closed');
      document.body.classList.add('has-docked-player');
      restoreBtn.hidden = true;
      try { localStorage.removeItem('soundya_dock_closed'); } catch (e) {}
    }

    closeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      closePlayer();
    });

    // Check if player should auto-open on playback
    setInterval(() => {
      if (player.classList.contains('closed')) {
        const isPlaying = window.lastStatus && (window.lastStatus.state === 'playing' || window.lastStatus.loading);
        if (isPlaying) {
          openPlayer();
        }
      }
    }, 800);

    // Initial state check
    if (localStorage.getItem('soundya_dock_closed') === '1') {
      const isPlaying = window.lastStatus && window.lastStatus.state === 'playing';
      if (!isPlaying) {
        closePlayer();
      }
    }

    // Popover outside clicks
    document.addEventListener('pointerdown', (e) => {
      if (psearch && !psearch.hidden && !psearch.contains(e.target) && (!psearchbtn || !psearchbtn.contains(e.target))) {
        if (typeof closeSearch === 'function') {
          closeSearch();
        } else {
          psearch.hidden = true;
          if (psearchbtn) {
            psearchbtn.classList.remove('on');
            psearchbtn.setAttribute('aria-expanded', 'false');
          }
        }
      }

      if (volpop && !volpop.hidden && !volpop.contains(e.target) && (!volbtn || !volbtn.contains(e.target))) {
        volpop.hidden = true;
        if (volbtn) volbtn.classList.remove('on');
      }

      if (picker && picker.style.display !== 'none' && !picker.contains(e.target) && (!plbtn || !plbtn.contains(e.target))) {
        picker.style.display = 'none';
      }
    });

    return true;
  }

  if (!setup()) {
    const observer = new MutationObserver(() => {
      if (setup()) observer.disconnect();
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
    window.addEventListener('DOMContentLoaded', setup);
    window.addEventListener('load', setup);
  }
})();
