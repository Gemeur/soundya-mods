// SysMon — Модуль мониторинга температуры, нагрузки и ресурсов для Soundya
(() => {
  const MOD_ID = 'sysmon';
  let pollTimer = null;
  let isModalOpen = false;
  let activeMetric = 'ram'; // 'ram' | 'cpu' | 'rom'
  let lastStats = null;

  async function fetchStats() {
    try {
      const res = await fetch('/api/sysmon');
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {}

    try {
      const res2 = await fetch('/api/system/info');
      if (res2.ok) {
        return await res2.json();
      }
    } catch (e) {}

    return null;
  }

  function getStatusClass(temp, load) {
    if (temp >= 70 || load >= 80) return 'alert';
    if (temp >= 58 || load >= 50) return 'warn';
    return '';
  }

  function esc(s) {
    if (!s) return '';
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  function updatePill(stats) {
    const pill = document.getElementById('sysmon-pill');
    if (!pill || !stats) return;

    const temp = stats.cpu_temp !== undefined && stats.cpu_temp !== null ? Math.round(stats.cpu_temp) : null;
    const loadNum = stats.cpu_load !== undefined && stats.cpu_load !== null ? Number(stats.cpu_load) : null;

    let text = '';
    if (temp !== null) text += `${temp}°C`;
    if (loadNum !== null) text += (text ? ' · ' : '') + `${loadNum.toFixed(2)}%`;

    const statusCls = getStatusClass(temp || 0, loadNum || 0);
    pill.className = `sysmon-pill ${statusCls}`.trim();
    const textNode = pill.querySelector('.sysmon-text');
    if (textNode) {
      textNode.textContent = text || 'Монитор';
    }
  }

  function renderDetailsBox(stats, prefix) {
    const titleEl = document.getElementById(`${prefix}-details-title`);
    const countEl = document.getElementById(`${prefix}-details-count`);
    const listEl = document.getElementById(`${prefix}-details-list`);
    if (!listEl || !stats) return;

    if (activeMetric === 'ram') {
      if (titleEl) titleEl.textContent = 'Оперативная память';
      const list = stats.ram_top || [];
      if (countEl) countEl.textContent = `${list.length} процессов`;
      if (!list.length) {
        listEl.innerHTML = '<div class="sysmon-empty">Нет данных о процессах</div>';
        return;
      }
      listEl.innerHTML = list.map(p => `
        <div class="sysmon-detail-row">
          <div class="sysmon-detail-info">
            <span class="sysmon-detail-name" title="${esc(p.name)}">${esc(p.name)}</span>
            <div class="sysmon-detail-bar">
              <div class="sysmon-detail-bar-fill" style="width: ${Math.min(100, Math.max(2, p.pct * 3))}%"></div>
            </div>
          </div>
          <div class="sysmon-detail-val">
            <span class="sysmon-detail-main">${p.mem_mb.toFixed(1)} МБ</span>
            <span class="sysmon-detail-badge">${p.pct}%</span>
          </div>
        </div>
      `).join('');
    } else if (activeMetric === 'cpu') {
      if (titleEl) titleEl.textContent = 'Нагрузка на процессор';
      const list = stats.cpu_top || [];
      if (countEl) countEl.textContent = `${list.length} процессов`;
      if (!list.length) {
        listEl.innerHTML = '<div class="sysmon-empty">Нет активных процессов</div>';
        return;
      }
      listEl.innerHTML = list.map(p => `
        <div class="sysmon-detail-row">
          <div class="sysmon-detail-info">
            <span class="sysmon-detail-name" title="${esc(p.name)}">${esc(p.name)}</span>
            <div class="sysmon-detail-bar">
              <div class="sysmon-detail-bar-fill" style="width: ${Math.min(100, Math.max(2, p.cpu))}%"></div>
            </div>
          </div>
          <div class="sysmon-detail-val">
            <span class="sysmon-detail-main">${Number(p.cpu).toFixed(2)}%</span>
            <span class="sysmon-detail-badge">CPU</span>
          </div>
        </div>
      `).join('');
    } else if (activeMetric === 'rom') {
      if (titleEl) titleEl.textContent = 'Накопитель /data';
      const list = stats.rom_top || [];
      if (countEl) countEl.textContent = `${list.length} папок`;
      if (!list.length) {
        listEl.innerHTML = '<div class="sysmon-empty">Нет данных о хранилище</div>';
        return;
      }
      listEl.innerHTML = list.map(r => `
        <div class="sysmon-detail-row">
          <div class="sysmon-detail-info">
            <span class="sysmon-detail-name" title="${esc(r.path || r.name)}">${esc(r.name)}</span>
            <div class="sysmon-detail-bar">
              <div class="sysmon-detail-bar-fill" style="width: ${Math.min(100, Math.max(2, r.pct * 2))}%"></div>
            </div>
          </div>
          <div class="sysmon-detail-val">
            <span class="sysmon-detail-main">${r.size_mb.toFixed(1)} МБ</span>
            <span class="sysmon-detail-badge">${r.pct}%</span>
          </div>
        </div>
      `).join('');
    }
  }

  function updateModal(stats) {
    if (!isModalOpen || !stats) return;

    // 1. CPU Card
    const temp = stats.cpu_temp !== null && stats.cpu_temp !== undefined ? Math.round(stats.cpu_temp) : '—';
    const load = stats.cpu_load !== null && stats.cpu_load !== undefined ? Number(stats.cpu_load) : 0;
    const cpuVal = document.getElementById('modal-card-val-cpu');
    const cpuSub = document.getElementById('modal-card-sub-cpu');
    const cpuBar = document.getElementById('modal-card-bar-cpu');
    if (cpuVal) cpuVal.textContent = `${temp}°C · ${load.toFixed(2)}%`;
    if (cpuSub) cpuSub.textContent = load >= 75 ? 'Высокая нагрузка' : (load >= 45 ? 'Умеренная нагрузка' : 'Низкая нагрузка');
    if (cpuBar) {
      cpuBar.style.width = `${Math.min(100, Math.max(0, load))}%`;
      cpuBar.className = `sysmon-card-bar-fill ${getStatusClass(Number(temp) || 0, load)}`.trim();
    }

    // 2. RAM Card
    const ramUsed = stats.ram_used_mb || 0;
    const ramTotal = stats.ram_total_mb || 1;
    const ramPct = stats.ram_pct !== undefined ? stats.ram_pct : Math.round((ramUsed / ramTotal) * 100);
    const ramVal = document.getElementById('modal-card-val-ram');
    const ramSub = document.getElementById('modal-card-sub-ram');
    const ramBar = document.getElementById('modal-card-bar-ram');
    if (ramVal) ramVal.textContent = `${ramPct}%`;
    if (ramSub) ramSub.textContent = `${ramUsed} / ${ramTotal} МБ`;
    if (ramBar) {
      ramBar.style.width = `${ramPct}%`;
      ramBar.className = `sysmon-card-bar-fill ${ramPct >= 85 ? 'alert' : ramPct >= 70 ? 'warn' : ''}`.trim();
    }

    // 3. ROM Card
    const romUsed = stats.rom_used_mb || 0;
    const romTotal = stats.rom_total_mb || 1;
    const romPct = stats.rom_pct !== undefined ? stats.rom_pct : Math.round((romUsed / romTotal) * 100);
    const romVal = document.getElementById('modal-card-val-rom');
    const romSub = document.getElementById('modal-card-sub-rom');
    const romBar = document.getElementById('modal-card-bar-rom');
    if (romVal) romVal.textContent = `${romPct}%`;
    if (romSub) romSub.textContent = `${romUsed} / ${romTotal} МБ`;
    if (romBar) romBar.style.width = `${romPct}%`;

    // 4. Update Details section
    renderDetailsBox(stats, 'modal');

    // 5. Uptime
    const uptimeEl = document.getElementById('modal-sysmon-uptime');
    if (uptimeEl && stats.uptime_str) {
      uptimeEl.textContent = stats.uptime_str;
    }
  }

  function updateSettingsBox(stats) {
    if (!stats) return;

    // 1. CPU Card
    const temp = stats.cpu_temp !== null && stats.cpu_temp !== undefined ? Math.round(stats.cpu_temp) : '—';
    const load = stats.cpu_load !== null && stats.cpu_load !== undefined ? Number(stats.cpu_load) : 0;
    const cpuVal = document.getElementById('set-card-val-cpu');
    const cpuSub = document.getElementById('set-card-sub-cpu');
    const cpuBar = document.getElementById('set-card-bar-cpu');
    if (cpuVal) cpuVal.textContent = `${temp}°C · ${load.toFixed(2)}%`;
    if (cpuSub) cpuSub.textContent = load >= 75 ? 'Высокая нагрузка' : (load >= 45 ? 'Умеренная нагрузка' : 'В норме');
    if (cpuBar) {
      cpuBar.style.width = `${Math.min(100, Math.max(0, load))}%`;
      cpuBar.className = `sysmon-card-bar-fill ${getStatusClass(Number(temp) || 0, load)}`.trim();
    }

    // 2. RAM Card
    const ramUsed = stats.ram_used_mb || 0;
    const ramTotal = stats.ram_total_mb || 1;
    const ramPct = stats.ram_pct !== undefined ? stats.ram_pct : Math.round((ramUsed / ramTotal) * 100);
    const ramVal = document.getElementById('set-card-val-ram');
    const ramSub = document.getElementById('set-card-sub-ram');
    const ramBar = document.getElementById('set-card-bar-ram');
    if (ramVal) ramVal.textContent = `${ramPct}%`;
    if (ramSub) ramSub.textContent = `${ramUsed} / ${ramTotal} МБ`;
    if (ramBar) {
      ramBar.style.width = `${ramPct}%`;
      ramBar.className = `sysmon-card-bar-fill ${ramPct >= 85 ? 'alert' : ramPct >= 70 ? 'warn' : ''}`.trim();
    }

    // 3. ROM Card
    const romUsed = stats.rom_used_mb || 0;
    const romTotal = stats.rom_total_mb || 1;
    const romPct = stats.rom_pct !== undefined ? stats.rom_pct : Math.round((romUsed / romTotal) * 100);
    const romVal = document.getElementById('set-card-val-rom');
    const romSub = document.getElementById('set-card-sub-rom');
    const romBar = document.getElementById('set-card-bar-rom');
    if (romVal) romVal.textContent = `${romPct}%`;
    if (romSub) romSub.textContent = `${romUsed} / ${romTotal} МБ`;
    if (romBar) romBar.style.width = `${romPct}%`;

    // 4. Update Details section
    renderDetailsBox(stats, 'set');
  }

  function setMetric(metric) {
    activeMetric = metric;

    // Update active classes on all cards (modal and settings)
    document.querySelectorAll('.sysmon-metric-card').forEach(card => {
      card.classList.toggle('active', card.dataset.metric === metric);
    });

    if (lastStats) {
      renderDetailsBox(lastStats, 'modal');
      renderDetailsBox(lastStats, 'set');
    }
  }

  function injectSettingsBlock() {
    if (document.getElementById('sysresbox')) return;
    const speakerSub = document.querySelector('.sub[data-sub="speaker"]');
    if (!speakerSub) return;

    const wrap = document.createElement('div');
    wrap.id = 'sysresbox-wrapper';
    wrap.className = 'sysmon-settings-wrapper';
    wrap.innerHTML = `
      <h2 class="section">Ресурсы устройства</h2>
      
      <div id="sysresbox" class="sysmon-container">
        <!-- 3 Interactive Metric Cards -->
        <div class="sysmon-cards-grid">
          <div class="sysmon-metric-card ${activeMetric === 'cpu' ? 'active' : ''}" data-metric="cpu" id="set-card-cpu">
            <div class="sysmon-card-top">
              <span class="sysmon-card-label">Процессор</span>
              <span class="sysmon-card-badge">CPU</span>
            </div>
            <div class="sysmon-card-val" id="set-card-val-cpu">—</div>
            <div class="sysmon-card-sub" id="set-card-sub-cpu">Загрузка...</div>
            <div class="sysmon-card-bar"><div class="sysmon-card-bar-fill" id="set-card-bar-cpu" style="width: 0%"></div></div>
          </div>

          <div class="sysmon-metric-card ${activeMetric === 'ram' ? 'active' : ''}" data-metric="ram" id="set-card-ram">
            <div class="sysmon-card-top">
              <span class="sysmon-card-label">Оперативная память</span>
              <span class="sysmon-card-badge">RAM</span>
            </div>
            <div class="sysmon-card-val" id="set-card-val-ram">—</div>
            <div class="sysmon-card-sub" id="set-card-sub-ram">—</div>
            <div class="sysmon-card-bar"><div class="sysmon-card-bar-fill" id="set-card-bar-ram" style="width: 0%"></div></div>
          </div>

          <div class="sysmon-metric-card ${activeMetric === 'rom' ? 'active' : ''}" data-metric="rom" id="set-card-rom">
            <div class="sysmon-card-top">
              <span class="sysmon-card-label">Накопитель /data</span>
              <span class="sysmon-card-badge">ROM</span>
            </div>
            <div class="sysmon-card-val" id="set-card-val-rom">—</div>
            <div class="sysmon-card-sub" id="set-card-sub-rom">—</div>
            <div class="sysmon-card-bar"><div class="sysmon-card-bar-fill" id="set-card-bar-rom" style="width: 0%"></div></div>
          </div>
        </div>

        <!-- Single Unified Details Box -->
        <div class="sysmon-details-box">
          <div class="sysmon-details-header">
            <div class="sysmon-details-title" id="set-details-title">Подробности</div>
            <span class="sysmon-details-count" id="set-details-count"></span>
          </div>
          <div class="sysmon-details-list" id="set-details-list">
            <div class="sysmon-empty">Загрузка данных...</div>
          </div>
        </div>
      </div>
    `;

    // Bind click events on the settings cards
    wrap.querySelectorAll('.sysmon-metric-card').forEach(card => {
      card.addEventListener('click', () => {
        setMetric(card.dataset.metric);
      });
    });

    const social = speakerSub.querySelector('.social');
    if (social && social.nextSibling) {
      speakerSub.insertBefore(wrap, social.nextSibling);
    } else {
      speakerSub.prepend(wrap);
    }
  }

  async function poll() {
    const stats = await fetchStats();
    if (stats) {
      lastStats = stats;
      updatePill(stats);
      updateModal(stats);
      injectSettingsBlock();
      updateSettingsBox(stats);
    }
  }

  function initUI() {
    if (document.getElementById('sysmon-pill')) return;

    // 1. Create top pill
    const pill = document.createElement('div');
    pill.id = 'sysmon-pill';
    pill.className = 'sysmon-pill';
    pill.title = 'Мониторинг ресурсов колонки';
    pill.innerHTML = `<span class="sysmon-dot"></span><span class="sysmon-text">Монитор</span>`;
    
    pill.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      openModal();
    });

    const headRight = document.querySelector('.headright') || document.querySelector('header .status') || document.querySelector('header');
    if (headRight) {
      headRight.insertBefore(pill, headRight.firstChild);
    } else {
      document.body.appendChild(pill);
    }

    // 2. Create Modal structure with interactive cards + single details box
    if (!document.getElementById('sysmon-modal')) {
      const modal = document.createElement('div');
      modal.id = 'sysmon-modal';
      modal.className = 'sysmon-modal';
      modal.innerHTML = `
        <div class="sysmon-card" onclick="event.stopPropagation()">
          <div class="sysmon-header">
            <div class="sysmon-title">
              <span>Мониторинг системы</span>
            </div>
            <button type="button" class="sysmon-close" id="sysmon-close-btn">&times;</button>
          </div>

          <!-- 3 Interactive Metric Cards -->
          <div class="sysmon-cards-grid">
            <div class="sysmon-metric-card ${activeMetric === 'cpu' ? 'active' : ''}" data-metric="cpu" id="modal-card-cpu">
              <div class="sysmon-card-top">
                <span class="sysmon-card-label">Процессор</span>
                <span class="sysmon-card-badge">CPU</span>
              </div>
              <div class="sysmon-card-val" id="modal-card-val-cpu">—</div>
              <div class="sysmon-card-sub" id="modal-card-sub-cpu">Загрузка...</div>
              <div class="sysmon-card-bar"><div class="sysmon-card-bar-fill" id="modal-card-bar-cpu" style="width: 0%"></div></div>
            </div>

            <div class="sysmon-metric-card ${activeMetric === 'ram' ? 'active' : ''}" data-metric="ram" id="modal-card-ram">
              <div class="sysmon-card-top">
                <span class="sysmon-card-label">Оперативная память</span>
                <span class="sysmon-card-badge">RAM</span>
              </div>
              <div class="sysmon-card-val" id="modal-card-val-ram">—</div>
              <div class="sysmon-card-sub" id="modal-card-sub-ram">—</div>
              <div class="sysmon-card-bar"><div class="sysmon-card-bar-fill" id="modal-card-bar-ram" style="width: 0%"></div></div>
            </div>

            <div class="sysmon-metric-card ${activeMetric === 'rom' ? 'active' : ''}" data-metric="rom" id="modal-card-rom">
              <div class="sysmon-card-top">
                <span class="sysmon-card-label">Накопитель /data</span>
                <span class="sysmon-card-badge">ROM</span>
              </div>
              <div class="sysmon-card-val" id="modal-card-val-rom">—</div>
              <div class="sysmon-card-sub" id="modal-card-sub-rom">—</div>
              <div class="sysmon-card-bar"><div class="sysmon-card-bar-fill" id="modal-card-bar-rom" style="width: 0%"></div></div>
            </div>
          </div>

          <!-- Unified Details Box -->
          <div class="sysmon-details-box">
            <div class="sysmon-details-header">
              <div class="sysmon-details-title" id="modal-details-title">Подробности</div>
              <span class="sysmon-details-count" id="modal-details-count"></span>
            </div>
            <div class="sysmon-details-list" id="modal-details-list">
              <div class="sysmon-empty">Загрузка процессов...</div>
            </div>
          </div>

          <div class="sysmon-footer">
            <span>Время работы: <strong id="modal-sysmon-uptime">—</strong></span>
            <span>Автообновление: 3 сек.</span>
          </div>
        </div>
      `;

      modal.addEventListener('click', () => closeModal());
      document.body.appendChild(modal);

      const closeBtn = document.getElementById('sysmon-close-btn');
      if (closeBtn) closeBtn.onclick = () => closeModal();

      // Bind card clicks in modal
      modal.querySelectorAll('.sysmon-metric-card').forEach(card => {
        card.addEventListener('click', () => {
          setMetric(card.dataset.metric);
        });
      });
    }

    // 3. Inject settings block into Колонка tab
    injectSettingsBlock();

    // Start background polling
    poll();
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = setInterval(() => {
      poll();
    }, isModalOpen ? 3000 : 8000);
  }

  function openModal() {
    const modal = document.getElementById('sysmon-modal');
    if (modal) {
      modal.classList.add('open');
      isModalOpen = true;
      poll();
      if (pollTimer) clearInterval(pollTimer);
      pollTimer = setInterval(poll, 3000);
    }
  }

  function closeModal() {
    const modal = document.getElementById('sysmon-modal');
    if (modal) {
      modal.classList.remove('open');
      isModalOpen = false;
      if (pollTimer) clearInterval(pollTimer);
      pollTimer = setInterval(poll, 8000);
    }
  }

  window.openSysmonModal = openModal;
  window.closeSysmonModal = closeModal;
  window.setSysmonMetric = setMetric;

  window.destroyMod_sysmon = function() {
    if (pollTimer) clearInterval(pollTimer);
    const pill = document.getElementById('sysmon-pill');
    if (pill) pill.remove();
    const modal = document.getElementById('sysmon-modal');
    if (modal) modal.remove();
    const settingsBox = document.getElementById('sysresbox-wrapper');
    if (settingsBox) settingsBox.remove();
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initUI);
  } else {
    initUI();
  }
})();
