// Lumya 88-LED Matrix Plugin for Soundya
(() => {
  function initLumya() {
    if (document.getElementById('nav-glow-btn')) return;

    function setGlowMode(active) {
      document.body.classList.toggle('glow-mode', active);
    }

    // 1. Add "Подсветка" button to main <nav>
    const nav = document.querySelector('nav');
    if (nav) {
      const glowBtn = document.createElement('button');
      glowBtn.id = 'nav-glow-btn';
      glowBtn.type = 'button';
      glowBtn.dataset.tab = 'glow';
      glowBtn.textContent = 'Подсветка';
      glowBtn.onclick = () => {
        document.querySelectorAll('nav button').forEach(x => x.classList.toggle('on', x === glowBtn));
        document.querySelectorAll('.tab').forEach(x => x.classList.toggle('on', x.id === 'tab-glow'));
        setGlowMode(true);
        try { localStorage.setItem('tab', 'glow'); } catch (e) {}
        if (typeof window.glowTabActivated === 'function') window.glowTabActivated();
      };

      const settingsBtn = document.querySelector('nav button[data-tab="settings"]');
      if (settingsBtn) {
        nav.insertBefore(glowBtn, settingsBtn);
      } else {
        nav.appendChild(glowBtn);
      }

      // Listen to other nav button clicks to stop live stream and disable glow-mode
      document.querySelectorAll('nav button:not(#nav-glow-btn)').forEach(b => {
        b.addEventListener('click', () => {
          const gTab = document.getElementById('tab-glow');
          if (gTab) gTab.classList.remove('on');
          glowBtn.classList.remove('on');
          setGlowMode(false);
          if (typeof window.glowTabDeactivated === 'function') window.glowTabDeactivated();
        });
      });
    }

    // 2. Inject #tab-glow section before #tab-settings
    if (!document.getElementById('tab-glow')) {
      const temp = document.createElement('div');
      temp.innerHTML = `<section class="tab" id="tab-glow">
    <div class="wrap">
      <header class="glow-bar">
        <div class="mark"><b>Свет</b><span>Станция 2</span></div>
        <div class="glow-bar-actions">
          <button class="switch" id="power" role="switch" aria-checked="true" disabled>
            <span class="knob" aria-hidden="true"></span><span id="powerText">Свет включён</span>
          </button>
        </div>
      </header>

      <div class="screen">
        <div class="glow-side">
        <figure class="stage">
          <div class="mirror-ambient" id="mirrorAmbient" aria-hidden="true"></div>
          <div class="mirror"><canvas id="panel" width="600" height="520" aria-label="Что сейчас горит на колонке"></canvas></div>
          <figcaption class="caption">
            <h1 class="now" id="now">Подключаюсь</h1>
            <p class="desc" id="desc">Колонка отдаёт настройки и картинку панели.</p>
            <p class="status" id="status" aria-live="polite"></p>
          </figcaption>
        </figure>
          <div class="group" id="slidersSec" aria-labelledby="lightHead">
            <h2 id="lightHead">Параметры эффекта</h2>
            <div class="well">
              <div class="slider"><label for="bri">Яркость</label><output id="briOut" for="bri"></output><input type="range" id="bri" min="2" max="100" step="1" disabled></div>
              <div class="slider" id="spdRow">
                <label for="spd">Скорость</label>
                <div style="display:inline-flex;align-items:center;gap:8px;justify-self:end;">
                  <button type="button" id="btnCenterSpd" class="btn-1x" title="Сбросить скорость на 1×">1×</button>
                  <output id="spdOut" for="spd"></output>
                </div>
                <input type="range" id="spd" min="0" max="100" step="1" disabled>
              </div>
              <div class="slider" id="intRow" hidden><label for="int" id="intLabel">Интенсивность</label><output id="intOut" for="int"></output><input type="range" id="int" min="0" max="100" step="1" disabled></div>
            </div>
          </div>
        </div>

        <div class="glow-controls">
          <div class="group" aria-labelledby="fxHead">
            <h2 id="fxHead">Режим и эффекты</h2>
            <div class="tabs" role="tablist" aria-label="Вид эффектов">
              <button type="button" role="tab" id="tabCalm" aria-selected="true" aria-controls="fxList">Статичный свет</button>
              <button type="button" role="tab" id="tabMusic" aria-selected="false" aria-controls="fxList">Под музыку</button>
              <button type="button" role="tab" id="tabPresets" aria-selected="false" aria-controls="presetsSec">Пресеты</button>
            </div>
            <div class="fx-grid skeleton" id="fxList" role="radiogroup" aria-labelledby="fxHead">
              <div class="fx-card"><span class="thumb"></span><div class="fx-info"><b class="fx-name">Эффект</b></div><div class="fx-check"></div></div>
              <div class="fx-card"><span class="thumb"></span><div class="fx-info"><b class="fx-name">Эффект</b></div><div class="fx-check"></div></div>
            </div>
            <div id="presetsSec" class="group" hidden>
              <div class="well preset-create">
                <input class="field" type="text" id="presetName" placeholder="Название пресета..." maxlength="32">
                <button type="button" class="ghost" id="presetSave">Сохранить текущий</button>
              </div>
              <div class="presets-grid" id="presetsList"></div>
            </div>
          </div>

          <div class="group" id="palSec" aria-labelledby="palHead" hidden>
            <h2 id="palHead">Цвета</h2>
            <div class="pals" id="pals" role="radiogroup" aria-labelledby="palHead"></div>
            <div class="well music-mood" id="musicMoodBox" hidden style="margin-top: 10px; padding: 12px 14px;">
              <div class="slider" style="padding: 0; border: 0;">
                <label for="musicSample">Скорость</label>
                <div style="display:inline-flex;align-items:center;gap:8px;justify-self:end;">
                  <button type="button" id="btnCenterMusicSample" class="btn-1x" title="Центрировать (5 с)">5 с</button>
                  <output id="musicSampleVal" for="musicSample">10.0 с</output>
                </div>
                <input type="range" id="musicSample" min="0" max="10" step="0.5" value="10.0">
              </div>
            </div>

            <div class="well own" id="own" hidden>
              <div class="chips" id="chips"></div>
              <div class="own-actions">
                <button type="button" class="ghost" id="ownAdd">Добавить цвет</button>
                <button type="button" class="ghost" id="ownDel">Убрать последний</button>
                <button type="button" class="ghost" id="ownReset">Сбросить</button>
              </div>
            </div>
          </div>

          <div class="group" id="colSec" aria-labelledby="colHead" hidden>
            <h2 id="colHead">Цвет</h2>
            <div class="presets color-presets" id="swatches" role="radiogroup" aria-labelledby="colHead"></div>

            <div class="colors" style="margin-top: 14px;">
              <label>
                <input type="color" id="pick" value="#ff3d5a">
                <span>Свой цвет: <b id="colVal" style="font-family: monospace; font-size: 14px; margin-left: 6px;">#FF3D5A</b></span>
              </label>
            </div>

            <div class="own-actions" style="margin-top: 12px;">
              <button type="button" class="ghost" id="colReset" style="min-height: 40px;">Сбросить по умолчанию</button>
            </div>
          </div>


        </div>
      </div>
    </div>
  </section>`;
      const tabGlow = temp.firstElementChild;
      const settingsTab = document.getElementById('tab-settings');
      if (settingsTab && settingsTab.parentNode) {
        settingsTab.parentNode.insertBefore(tabGlow, settingsTab);
      } else {
        document.body.appendChild(tabGlow);
      }
    }

    // 3. Put stock Soundya Ambilight to sleep and replace with Clean Lumya card
    try {
      fetch('/api/settings', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ ring: false, light_bright: 0 })
      });
      const stockRing = document.getElementById('ring');
      if (stockRing && stockRing.checked) { stockRing.checked = false; }
    } catch(e) {}

    const ambiBtn = document.querySelector('#tab-settings .subnav button[data-sub="light"]');
    if (ambiBtn) {
      ambiBtn.dataset.origText = ambiBtn.textContent;
      ambiBtn.textContent = 'Подсветка';
    }

    window.toggleHelp = function(id) {
      const el = document.getElementById(id);
      if (el) el.hidden = !el.hidden;
    };

    const ambiSub = document.querySelector('#tab-settings .sub[data-sub="light"]');
    if (ambiSub && !ambiSub.dataset.lumyaInjected) {
      ambiSub.dataset.origHtml = ambiSub.innerHTML;
      ambiSub.dataset.lumyaInjected = "true";
      ambiSub.innerHTML = `<h2 style="margin-top:0;padding-top:0;border-top:0">Подсветка Станции 2</h2>
    <p class="hint">Светодиодная матрица 15×13 RGBW Станции 2: 33 процедурных эффекта, светомузыка с аппаратным захватом звука через ALSA loopback и пресеты.</p>

    <h2 class="section">Параметры работы <button type="button" class="help-btn" onclick="toggleHelp('help-light')" title="Справка по режимам" aria-label="Справка">?</button></h2>
    <div class="help-box" id="help-light" hidden>
      <table class="help-table">
        <tr><td class="help-cmd">Уступать Алисе</td><td class="help-desc">Когда колонка слышит обращение к Алисе, матрица временно гасит светомузыку и показывает стандартную анимацию ответа Алисы</td></tr>
        <tr><td class="help-cmd">Гасить без дела</td><td class="help-desc">Автоматически выключает светодиоды матрицы через выбранное время при отсутствии музыки</td></tr>
        <tr><td class="help-cmd">Ночной режим</td><td class="help-desc">В заданные часы выключает подсветку или приглушает максимальную яркость до указанного предела</td></tr>
      </table>
    </div>
    <input type="checkbox" id="yield" checked style="display: none;" aria-hidden="true">

    <label class="field" style="margin-top: 14px;">Гасить без дела
      <select id="idle">
        <option value="0">Никогда</option>
        <option value="15">Через 15 мин</option>
        <option value="30">Через 30 мин</option>
        <option value="60">Через 1 час</option>
        <option value="120">Через 2 часа</option>
      </select>
      <span class="hint">Если музыка не играет и эффекты не менялись. Панель включится от звука или любого действия.</span>
    </label>

    <label class="switch" style="margin-top: 18px;">
      <input type="checkbox" id="pauseAmbient" checked>
      <span><b>При паузе переключать на фоновый свет</b><br>
        <span class="hint">Когда музыка на паузе или трек закончился, матрица плавно переходит в спокойный свет вместо темноты</span></span>
    </label>

    <div id="pauseEffectRow" style="margin-top: 10px;">
      <label class="field">Фоновый эффект при паузе
        <select id="pauseEffect">
          <option value="aurora">Сияние</option>
          <option value="flow">Перелив</option>
          <option value="breathe">Дыхание</option>
          <option value="waves">Волны</option>
          <option value="fire">Огонь</option>
          <option value="static">Статичный цвет</option>
        </select>
        <span class="hint">Этот эффект включится автоматически, как только музыка встанет на паузу.</span>
      </label>
    </div>

    <label class="switch" style="margin-top: 18px;">
      <input type="checkbox" id="night">
      <span><b>Ночной режим</b><br>
        <span class="hint">В указанные часы матрица выключается или снижает яркость</span></span>
    </label>

    <div class="row" id="nightTimes" style="margin-top: 8px; gap: 16px; display: flex;">
      <div style="flex: 1;">
        <div style="font-size: 13px; color: var(--muted); margin-bottom: 4px;">С:</div>
        <div style="display: flex; gap: 6px; align-items: center;">
          <select id="nightFromH" aria-label="Часы начала (24ч)" style="flex: 1; text-align: center; font-variant-numeric: tabular-nums;"></select>
          <span style="color: var(--muted); font-weight: bold;">:</span>
          <select id="nightFromM" aria-label="Минуты начала" style="flex: 1; text-align: center; font-variant-numeric: tabular-nums;"></select>
        </div>
      </div>
      <div style="flex: 1;">
        <div style="font-size: 13px; color: var(--muted); margin-bottom: 4px;">До:</div>
        <div style="display: flex; gap: 6px; align-items: center;">
          <select id="nightToH" aria-label="Часы окончания (24ч)" style="flex: 1; text-align: center; font-variant-numeric: tabular-nums;"></select>
          <span style="color: var(--muted); font-weight: bold;">:</span>
          <select id="nightToM" aria-label="Минуты окончания" style="flex: 1; text-align: center; font-variant-numeric: tabular-nums;"></select>
        </div>
      </div>
      <input type="hidden" id="nightFrom" value="23:00">
      <input type="hidden" id="nightTo" value="07:00">
    </div>

    <div id="nightBriBox" style="margin-top: 12px; display: block;">
      <label class="field" style="margin-top: 0;">Максимальная яркость ночью: <b id="nightBriVal">0% (выключается)</b>
        <input type="range" id="nightBri" min="0" max="100" step="5" value="0" style="margin-top: 8px; width: 100%;">
        <span class="hint">Если выкручено в 0% — панель полностью выключается. Иначе яркость ночью снижается до этого значения.</span>
      </label>
    </div>`;
    }

    // 4. Run Glow LED Matrix Controller
    (() => {


const $ = id => document.getElementById(id);
const glowEl = document.getElementById("tab-glow");
const token = name => ((glowEl ? getComputedStyle(glowEl).getPropertyValue(name) : "") || getComputedStyle(document.documentElement).getPropertyValue(name) || "").trim();

// what each effect looks like, in words; names come from the speaker
const DESC = {
  aurora:  "Шторы света медленно плывут по панели",
  flow:    "Вся панель неспешно меняет цвет",
  breathe: "Один цвет плавно гаснет и разгорается",
  waves:   "Кольца света расходятся от центра",
  swirl:   "Цвета кружат вокруг логотипа",
  lava:    "Мягкие пятна сливаются и расходятся",
  static:  "Ровный свет одного цвета",
  pulse:   "Свет вспыхивает и расходится в такт басам",
  voice:   "Мягкая волна по центру, как у Алисы, когда она говорит",
  borealis:"Колышущиеся занавеси с лучами, как настоящее северное сияние",
  plasma:  "Переливающийся узор из бегущих волн",
  fire:    "Языки пламени вырываются снизу, лучше с палитрой «Угли»",
  twinkle: "Огоньки вспыхивают и гаснут каждый в своём ритме",
  meteors: "Светящиеся метеоры с шлейфом летят по диагонали",
  scanner: "Полоса света ходит туда-обратно со следом",
  juggle:  "Цветные точки носятся по панели и оставляют след",
  fireworks:"Залпы: кольца расходятся и гаснут",
  radar:   "Луч обходит панель по кругу с затухающим хвостом",
  rain:    "Светящиеся капли падают колонками с разной скоростью",
  sunrise: "Свет поднимается снизу вверх и снова опускается",
  stripes: "Бегущие наклонные полосы",
  auto:    "Авто-микс: сам подбирает эффект под характер музыки (дроп, бит, вокал, эмбиент)",
  metronome:"Метроном: волны расходятся в такт BPM музыки, адаптируясь под темп",
  shockwave:"На каждый удар баса от логотипа расходится кольцо",
  field:   "Частицы по частотам: цвет по спектру, высота по фазе, размер по амплитуде",
  bars:    "Spectrum Bars (FFT): восемь динамических столбцов по частотам, басы слева",
  rms:     "RMS: светящийся шар раздувается с громкостью",
  beatflash:"Бит: ритмическая вспышка с радиальной волной и сменой цвета по долям",
  tunnel:  "Бит и громкость: кольца летят на тебя из глубины, на ударах тоннель рывком ускоряется",
  onsets:  "Вспышки событий: фейерверки по типу звука (залпы баса, снейр-салюты, тарелки-искры)",
  pitch:   "Тон: адаптивная мелодическая линия, высота по вертикали, цвет по ноте",
  centroid:"Центроид: полоса поднимается и меняет цвет вместе с яркостью звука",
  flux:    "Поток: вихри цветовых пятен закручиваются при изменении спектра",
  timbre:  "MFCC: тембр рисунком из колец, по кольцу на коэффициент",
};
const SWATCHES = ["#ffd2a1", "#ff7a3d", "#ff3d5a", "#ff5fb0", "#8a5cff", "#3d8bff", "#3de0ff", "#3dffa8"];
const CHECK = '<svg viewBox="0 0 14 14" aria-hidden="true"><path d="M3 7.5l2.6 2.5L11 4.5" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';

// LED positions on the 15x13 checkerboard (same table as the speaker uses)
const LAYOUT = (() => {
  const l = [], odd = [1,3,5,7,9,11,13], even = [0,2,4,6,8,10,12,14];
  const row = (y, xs) => xs.forEach(x => l.push([x, y]));
  row(0,odd); row(1,even); row(2,odd); row(3,even); row(4,odd);
  row(5,[0,2,12,14]); row(6,[1,13]); row(7,[0,2,12,14]);
  row(8,odd); row(9,even); row(10,odd); row(11,even); row(12,odd);
  l.push([8,7],[6,7],[6,5],[8,5]);
  return l;
})();

let cat = null, st = null, sending = null, pending = null, tab = "music";

async function api(path, body) {
  const r = await fetch(path, body ? {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(body)} : {});
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}

// coalesce rapid slider moves into one request at a time
function push(patch) {
  pending = Object.assign(pending || {}, patch);
  Object.assign(st, patch);
  updateControls();
  if (patch.palette !== undefined || patch.custom !== undefined || patch.color !== undefined) {
    lastThumb.clear();
    pvIds = "";
    if (cat) {
      const isMusic = tab === "music";
      const effects = cat.effects.filter(e => !!e.music === isMusic);
      previews(effects.map(e => e.id).join(","));
    }
  }
  if (sending) return;
  sending = (async () => {
    while (pending) {
      const p = pending; pending = null;
      try { st = Object.assign(await api("/api/state", p), pending || {}); }
      catch (e) { setStatus("Колонка не приняла настройку: " + e.message); }
    }
    sending = null;
  })();
}

function radio(cls, html, checked, onPick, label) {
  const b = document.createElement("button");
  b.type = "button"; b.className = cls; b.innerHTML = html;
  b.setAttribute("role", "radio"); b.setAttribute("aria-checked", checked);
  if (label) b.setAttribute("aria-label", label);
  b.onclick = onPick;
  return b;
}

let currentFxTab = "";
function buildFxList() {
  if (!cat || !st) return;
  const isMusic = tab === "music";
  const wantedTab = isMusic ? "music" : "calm";
  const list = $("fxList");
  if (!list) return;

  if (currentFxTab === wantedTab && list.children.length > 0 && !list.classList.contains("skeleton")) {
    return;
  }
  currentFxTab = wantedTab;
  list.classList.remove("skeleton");
  list.textContent = "";

  const effects = cat.effects.filter(e => !!e.music === isMusic);

  for (const e of effects) {
    const isSel = e.id === st.effect;
    const card = radio("fx-card",
      `<canvas class="thumb" width="52" height="44" data-fx="${e.id}" aria-hidden="true"></canvas>` +
      `<div class="fx-info">` +
        `<b class="fx-name">${e.name}</b>` +
        
      `</div>` +
      `<div class="fx-check">${CHECK}</div>`,
      isSel, () => push({effect: e.id}), e.name);
    card.dataset.id = e.id;
    list.append(card);
  }

  thumbs = new Map([...list.querySelectorAll("canvas[data-fx]")].map(c => [c.dataset.fx, c]));
  for (const [id, c] of thumbs) {
    const hex = lastThumb.get(id);
    if (hex) drawDots(c, hex, 0);
  }
  previews(effects.map(e => e.id).join(","));
}

function buildPalettes() {
  const pals = $("pals");
  if (!pals || !cat || !st) return;
  pals.textContent = "";
  for (const p of cat.palettes) {
    const b = radio("pal", `<i></i>${p.name}`, p.id === st.palette, () => push({palette: p.id}));
    b.dataset.id = p.id;
    b.querySelector("i").style.background = `linear-gradient(90deg,${p.colors.concat(p.colors[0]).join(",")})`;
    pals.append(b);
  }
  const own = radio("pal", `<i></i>Своя`, st.palette === "custom", () => push({palette: "custom"}));
  own.dataset.id = "custom";
  own.querySelector("i").style.background = `linear-gradient(90deg,${st.custom.concat(st.custom[0]).join(",")})`;
  pals.append(own);
}

function setTab(name) {
  tab = name;
  $("tabMusic").setAttribute("aria-selected", name === "music");
  $("tabCalm").setAttribute("aria-selected", name === "calm");
  $("tabPresets").setAttribute("aria-selected", name === "presets");

  const isPresets = name === "presets";
  const isFx = !isPresets;

  const list = $("fxList");
  list.hidden = !isFx;
  $("presetsSec").hidden = !isPresets;
  $("presetsSec").style.display = isPresets ? "grid" : "none";
  list.style.display = isFx ? "grid" : "none";

  if (!isFx && pv) { pv.close(); pv = null; pvIds = ""; }
  if (isPresets) renderPresets();
  if (isFx) buildFxList();
  updateControls();
}
window.setGlowTab = setTab;
$("tabMusic").onclick = () => setTab("music");
$("tabCalm").onclick = () => setTab("calm");
$("tabPresets").onclick = () => setTab("presets");
if ($("btnSettings")) $("btnSettings").onclick = () => openSettings('light');

try { localStorage.removeItem("lumya-glow-theme"); localStorage.removeItem("soundya-glow-theme"); } catch(e) {}

function sliderFill(el) { el.style.setProperty("--fill", ((el.value - el.min) / (el.max - el.min) * 100) + "%"); }

function updateControls() {
  if (!cat || !st) return;
  const fx = cat.effects.find(e => e.id === st.effect) || cat.effects[0];
  $("now").textContent = fx.name;
  if ($("desc")) $("desc").textContent = "";

  const isParams = tab === "params";
  const isPresets = tab === "presets";

  if (!isParams && !isPresets) {
    const list = $("fxList");
    if (list) {
      list.querySelectorAll(".fx-card").forEach(b => {
        const isSel = b.dataset.id === st.effect;
        b.setAttribute("aria-checked", isSel);
      });
    }
  }

  $("palSec").hidden = isParams || isPresets || !fx.palette;
  $("colSec").hidden = isParams || isPresets || !fx.color;
  $("slidersSec").hidden = isParams || isPresets;
  $("palSec").style.display = (isParams || isPresets || !fx.palette) ? "none" : "grid";
  $("colSec").style.display = (isParams || isPresets || !fx.color) ? "none" : "grid";
  $("slidersSec").style.display = (isParams || isPresets) ? "none" : "grid";
  if ($("spdRow")) $("spdRow").hidden = fx.id === "metronome" || fx.id === "static";
  $("intRow").hidden = !fx.intensity;
  $("intLabel").textContent = fx.hint || "Интенсивность";

  const pals = $("pals");
  if (!pals.children.length) {
    buildPalettes();
  } else {
    pals.querySelectorAll(".pal").forEach(b => {
      const isSel = b.dataset.id === st.palette;
      b.setAttribute("aria-checked", isSel);
    });
  }
  renderOwn(fx);
  updateMusicMoodUI();
  renderSwatches();

  if ($("hue") && document.activeElement !== $("hue")) $("hue").value = hexToHue(st.color);
  if ($("hueOut")) $("hueOut").textContent = st.color.toUpperCase();
  if ($("colVal")) $("colVal").textContent = (st.color || "").toUpperCase();
  document.documentElement.style.setProperty("--hue-color", st.color);
  const gTab = document.getElementById("tab-glow"); if (gTab) gTab.style.setProperty("--hue-color", st.color);

  for (const [id, v] of [["bri", Math.round(st.brightness*100)], ["spd", Math.round(st.speed*100)], ["int", Math.round((st.intensity ?? 0.5)*100)]]) {
    const el = $(id);
    el.disabled = false;
    if (document.activeElement !== el) el.value = v;
    sliderFill(el);
  }
  $("briOut").textContent = Math.round(st.brightness*100) + "%";
  $("spdOut").textContent = "×" + Math.pow(6, 2*st.speed - 1).toFixed(2).replace(/\.?0+$/,"");
  $("intOut").textContent = Math.round((st.intensity ?? 0.5)*100) + "%";

  const y = $("yield");
  if (y) {
    y.disabled = false;
    if (y.type === "checkbox") y.checked = true; if (!st.yield) push({yield: true});
    else y.setAttribute("aria-checked", st.yield);
  }
  const idle = $("idle");
  if (idle) {
    idle.disabled = false;
    if (![...idle.options].some(o => +o.value === st.idleOff)) idle.add(new Option(st.idleOff + " мин", st.idleOff));
    idle.value = String(st.idleOff);
  }
  const pa = $("pauseAmbient");
  if (pa) {
    pa.disabled = false;
    pa.checked = st.pauseAmbient !== false;
  }
  const pe = $("pauseEffect");
  if (pe) {
    pe.disabled = false;
    pe.value = st.pauseEffect || "aurora";
    if ($("pauseEffectRow")) $("pauseEffectRow").style.display = (st.pauseAmbient !== false) ? "block" : "none";
  }
  const nt = $("night");
  if (nt) {
    nt.disabled = false;
    if (nt.type === "checkbox") nt.checked = !!st.night;
    else nt.setAttribute("aria-checked", st.night);
  }
  const ntBox = $("nightTimes");
  if (ntBox) {
    ntBox.hidden = false;
    ntBox.style.display = "flex";
  }
  const nb = $("nightBri");
  const nbVal = Math.round((st.nightBrightness ?? 0) * 100);
  if (nb) {
    if (document.activeElement !== nb) nb.value = nbVal;
    if ($("nightBriVal")) {
      $("nightBriVal").textContent = nbVal === 0 ? "0% (выключается)" : nbVal + "%";
    }
  }
  const nbBox = $("nightBriBox");
  if (nbBox) {
    nbBox.style.display = "block";
  }
  init24hNightPicker();
  for (const id of ["nightFrom", "nightTo"]) {
    const el = $(id);
    if (el && document.activeElement !== el && st[id]) el.value = st[id];
    const p = id === "nightFrom" ? "From" : "To";
    const selH = $("night" + p + "H");
    const selM = $("night" + p + "M");
    if (selH && selM && st[id]) {
      const [h, m] = st[id].split(":");
      if (h && document.activeElement !== selH) selH.value = h.padStart(2, '0');
      if (m && document.activeElement !== selM) {
        if (![...selM.options].some(o => o.value === m)) {
          const opt = document.createElement('option');
          opt.value = m;
          opt.textContent = m;
          selM.appendChild(opt);
        }
        selM.value = m;
      }
    }
  }
  const pw = $("power");
  if (pw) {
    pw.disabled = false;
    pw.setAttribute("aria-checked", st.power);
  }
  if ($("powerText")) $("powerText").textContent = st.power ? "Свет включён" : "Свет выключен";
}

function render() {
  buildFxList();
  updateControls();
}

const PLUS = '<svg viewBox="0 0 18 18" aria-hidden="true"><path d="M9 3v12M3 9h12" fill="none" stroke-width="2" stroke-linecap="round"/></svg>';

const PRESET_COLORS = [
  { name: "Оранжевый", hex: "#ff7a3d" },
  { name: "Алый", hex: "#ff3d5a" },
  { name: "Розовый", hex: "#ff5fb0" },
  { name: "Фиолетовый", hex: "#8a5cff" },
  { name: "Синий", hex: "#3d8bff" },
  { name: "Голубой", hex: "#3de0ff" },
  { name: "Мята", hex: "#3dffa8" },
  { name: "Жёлтый", hex: "#ffd000" },
  { name: "Тёплый белый", hex: "#fff0dd" },
];

function renderSwatches() {
  const sw = $("swatches");
  if (!sw) return;
  if (!sw.children.length) {
    for (const c of PRESET_COLORS) {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "preset";
      b.dataset.c = c.hex.toLowerCase();
      b.innerHTML = `<i style="background:${c.hex}"></i>${c.name}`;
      b.onclick = () => push({color: c.hex});
      sw.append(b);
    }
  }
  const cur = (st.color || "").toLowerCase();
  for (const b of sw.querySelectorAll("button.preset")) {
    const isSel = b.dataset.c === cur;
    b.classList.toggle("on", isSel);
    b.setAttribute("aria-checked", isSel);
  }
  const pick = $("pick"), colVal = $("colVal");
  if (pick && document.activeElement !== pick) pick.value = st.color;
  if (colVal) colVal.textContent = (st.color || "").toUpperCase();
}

// the own palette: 2 to 5 colours, each a native picker
function renderOwn(fx) {
  $("own").hidden = !fx.palette || st.palette !== "custom";
  const chips = $("chips");
  if (chips.children.length !== st.custom.length) {
    chips.textContent = "";
    st.custom.forEach((c, i) => {
      const lab = document.createElement("label");
      lab.className = "chip picker";
      lab.innerHTML = `<input type="color" aria-label="Цвет ${i+1} своей палитры">`;
      lab.querySelector("input").oninput = e => {
        const next = st.custom.slice(); next[i] = e.target.value;
        push({custom: next, palette: "custom"});
      };
      chips.append(lab);
    });
  }
  const ownPill = document.querySelector('#tab-glow .pal[data-id="custom"] i');
  if (ownPill) {
    ownPill.style.background = `linear-gradient(90deg,${st.custom.concat(st.custom[0]).join(",")})`;
  }
  [...chips.children].forEach((lab, i) => {
    lab.style.background = st.custom[i];
    const inp = lab.querySelector("input");
    if (document.activeElement !== inp) inp.value = st.custom[i];
  });
  $("ownAdd").disabled = st.custom.length >= 5;
  $("ownDel").disabled = st.custom.length <= 2;
}
$("ownAdd").onclick = () => {
  const last = st.custom[st.custom.length - 1];
  push({custom: st.custom.concat(hueToHex((hexToHue(last) + 70) % 360)), palette: "custom"});
};
$("ownDel").onclick = () => push({custom: st.custom.slice(0, -1), palette: "custom"});
// back to the factory look: the colour of the single-colour effects and the owner's own palette
const DEFAULT_COLOR = "#ff7a3d", DEFAULT_OWN = ["#ff5e3a", "#ffb84d", "#3d8bff"];
$("colReset").onclick = () => push({color: DEFAULT_COLOR});
$("ownReset").onclick = () => push({custom: DEFAULT_OWN, palette: "custom"});

function hexToHue(hex) {
  const n = parseInt(hex.slice(1), 16), r = (n>>16&255)/255, g = (n>>8&255)/255, b = (n&255)/255;
  const mx = Math.max(r,g,b), mn = Math.min(r,g,b), d = mx - mn;
  if (!d) return 0;
  const h = mx === r ? ((g-b)/d) % 6 : mx === g ? (b-r)/d + 2 : (r-g)/d + 4;
  return Math.round((h*60 + 360) % 360);
}
function hueToHex(h) { // saturated, lightness 55%
  const f = n => { const k = (n + h/30) % 12;
    return Math.round(255*(.55 - .45*Math.max(-1, Math.min(k-3, 9-k, 1)))).toString(16).padStart(2,"0"); };
  return "#" + f(0) + f(8) + f(4);
}
if ($("pick")) $("pick").oninput = e => {
  if ($("colVal")) $("colVal").textContent = e.target.value.toUpperCase();
  push({color: e.target.value});
};
$("bri").oninput = e => push({brightness: e.target.value/100});
$("spd").oninput = e => push({speed: e.target.value/100});
if ($("btnCenterSpd")) $("btnCenterSpd").onclick = () => push({speed: 0.5});
if ($("spdOut")) { $("spdOut").style.cursor = "pointer"; $("spdOut").title = "Сбросить на 1×"; $("spdOut").onclick = () => push({speed: 0.5}); }
$("int").oninput = e => push({intensity: e.target.value/100});
if ($("yield")) {
  if ($("yield").tagName === "INPUT") $("yield").onchange = e => push({yield: e.target.checked});
  else $("yield").onclick = () => push({yield: !st.yield});
}
// the speaker runs on UTC: every night-mode edit carries this phone's offset
const tz = () => -new Date().getTimezoneOffset();

function init24hNightPicker() {
  const hours = Array.from({length: 24}, (_, i) => String(i).padStart(2, '0'));
  const minutes = ['00', '05', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55'];
  for (const p of ['From', 'To']) {
    const selH = $('night' + p + 'H');
    const selM = $('night' + p + 'M');
    if (!selH || selH.options.length > 0) continue;
    hours.forEach(h => {
      const o = document.createElement('option');
      o.value = h;
      o.textContent = h;
      selH.appendChild(o);
    });
    minutes.forEach(m => {
      const o = document.createElement('option');
      o.value = m;
      o.textContent = m;
      selM.appendChild(o);
    });
    const onSelectChange = () => {
      const timeStr = `${selH.value}:${selM.value}`;
      if ($('night' + p)) $('night' + p).value = timeStr;
      const patch = {};
      patch['night' + p] = timeStr;
      patch.tz = tz();
      push(patch);
    };
    selH.onchange = onSelectChange;
    selM.onchange = onSelectChange;
  }
}
init24hNightPicker();

if ($("idle")) $("idle").onchange = e => push({idleOff: +e.target.value});
if ($("pauseAmbient")) {
  $("pauseAmbient").onchange = e => {
    push({pauseAmbient: e.target.checked});
    if ($("pauseEffectRow")) $("pauseEffectRow").style.display = e.target.checked ? "block" : "none";
  };
}
if ($("pauseEffect")) $("pauseEffect").onchange = e => push({pauseEffect: e.target.value});
if ($("night")) {
  if ($("night").tagName === "INPUT") $("night").onchange = e => push({night: e.target.checked, tz: tz()});
  else $("night").onclick = () => push({night: !st.night, tz: tz()});
}
if ($("nightFrom")) $("nightFrom").onchange = e => { if (e.target.value) push({nightFrom: e.target.value, tz: tz()}); };
if ($("nightTo")) $("nightTo").onchange = e => { if (e.target.value) push({nightTo: e.target.value, tz: tz()}); };
if ($("nightBri")) {
  $("nightBri").oninput = e => {
    const v = +e.target.value;
    if ($("nightBriVal")) $("nightBriVal").textContent = v === 0 ? "0% (выключается)" : v + "%";
    push({nightBrightness: v / 100});
  };
}
if ($("power")) $("power").onclick = () => push({power: !st.power});

// ---- presets ----
let presetsData = [];
async function loadPresets() {
  try {
    presetsData = await api("/api/presets");
    if (tab === "presets") renderPresets();
  } catch (e) { console.warn("presets load err", e); }
}

function renderPresets() {
  const container = $("presetsList");
  if (!container) return;
  container.textContent = "";
  if (!presetsData || !presetsData.length) {
    container.innerHTML = '<p class="status">Сохранённых пресетов пока нет</p>';
    return;
  }
  for (const p of presetsData) {
    const card = document.createElement("div");
    card.className = "preset-card";
    const isActive = st && p.effect === st.effect &&
      (!p.palette || p.palette === st.palette) &&
      (!p.color || p.color.toLowerCase() === st.color.toLowerCase());
    card.setAttribute("data-active", isActive ? "true" : "false");

    const top = document.createElement("div");
    top.className = "preset-card-top";
    const nameEl = document.createElement("div");
    nameEl.className = "preset-name";
    nameEl.textContent = p.name;
    top.append(nameEl);

    if (!p.builtin) {
      const delBtn = document.createElement("button");
      delBtn.type = "button";
      delBtn.className = "preset-del";
      delBtn.title = "Удалить пресет";
      delBtn.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>';
      delBtn.onclick = async (e) => {
        e.stopPropagation();
        if (confirm(`Удалить пресет «${p.name}»?`)) {
          try {
            const r = await fetch("/api/presets?id=" + encodeURIComponent(p.id), {method: "DELETE"});
            presetsData = await r.json();
            renderPresets();
          } catch (err) { setStatus("Ошибка удаления: " + err.message); }
        }
      };
      top.append(delBtn);
    }
    card.append(top);

    const meta = document.createElement("div");
    meta.className = "preset-meta";
    const fxName = (cat && cat.effects.find(e => e.id === p.effect)?.name) || p.effect;
    let colorPreview = "";
    if (p.color) {
      colorPreview = `<span class="preset-dot" style="background:${p.color}"></span>`;
    } else if (p.palette && cat) {
      const pal = cat.palettes.find(pl => pl.id === p.palette);
      if (pal && pal.colors.length) {
        colorPreview = `<span class="preset-dot" style="background:${pal.colors[0]}"></span>`;
      }
    }
    meta.innerHTML = `${colorPreview}<span>${fxName} · ${Math.round(p.brightness*100)}%</span>`;
    card.append(meta);

    card.onclick = async () => {
      try {
        st = await api("/api/presets/apply", {id: p.id});
        render();
        renderPresets();
      } catch (err) { setStatus("Ошибка применения пресета: " + err.message); }
    };

    container.append(card);
  }
}

$("presetSave").onclick = async () => {
  const inp = $("presetName");
  const name = inp.value.trim();
  if (!name) { inp.focus(); return; }
  try {
    presetsData = await api("/api/presets", {name});
    inp.value = "";
    renderPresets();
  } catch (err) { setStatus("Ошибка сохранения пресета: " + err.message); }
};

// ---- live mirror ----
const cv = $("panel"), ctx = cv.getContext("2d");
const LED_OFF = token("--color-led-off") || "#0b0c0e";
let statusText = "";
function setStatus(t, retry) {
  if (t === statusText && !retry) return;
  statusText = t;
  const s = $("status"); s.textContent = t;
  if (retry) {
    const b = document.createElement("button"); b.type = "button"; b.textContent = "Повторить"; b.onclick = start;
    s.append(b);
  }
}

const isMobile = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0) || (window.innerWidth <= 768);

// draws 88 LED colours (hex, from offset `at` in `line`) onto a canvas; returns their sum
function drawDots(c, line, at) {
  const g2 = c.getContext("2d"), W = c.width, H = c.height, big = W > 200;
  const padX = big ? 0 : 2.5, padY = big ? 0 : 2;
  const netW = W - padX * 2, netH = H - padY * 2;
  const sx = netW / 15, sy = netH / 13;
  g2.globalCompositeOperation = "source-over";
  g2.fillStyle = LED_OFF || "#0b0c0e"; g2.fillRect(0, 0, W, H);
  g2.globalCompositeOperation = "lighter";

  if (!big) {
    const dotW = sx * 1.2, dotH = sy * 1.2;
    for (let i = 0; i < 88; i++) {
      const hex = line.substr(at + i * 6, 6);
      if (hex === "000000" || !hex) continue;
      const [x, y] = LAYOUT[i];
      g2.fillStyle = "#" + hex;
      g2.fillRect(padX + (x + .5) * sx - sx * .6, padY + (y + .5) * sy - sy * .6, dotW, dotH);
    }
    return [0, 0, 0];
  }

  let ar = 0, ag = 0, ab = 0;
  for (let i = 0; i < 88; i++) {
    const n = parseInt(line.substr(at + i * 6, 6), 16);
    if (!n) continue;
    const r = n >> 16 & 255, g = n >> 8 & 255, b = n & 255;
    ar += r; ag += g; ab += b;
    const [x, y] = LAYOUT[i], cx = padX + (x + .5) * sx, cy = padY + (y + .5) * sy;
    g2.fillStyle = `rgb(${r},${g},${b})`;
    g2.beginPath();
    g2.arc(cx, cy, sx * 1.15, 0, 6.2831853);
    g2.fill();
  }
  return [ar, ag, ab];
}

// effect thumbnails: animated preview stream from engine with visibility culling & RAF batching
let thumbs = new Map(), lastThumb = new Map(), pv = null, pvIds = "";
let visibleThumbs = new Set();
const thumbObserver = (typeof IntersectionObserver !== "undefined") ? new IntersectionObserver((entries) => {
  for (const entry of entries) {
    const id = entry.target.dataset.fx;
    if (id) {
      if (entry.isIntersecting) {
        visibleThumbs.add(id);
        const hex = lastThumb.get(id);
        if (hex) drawDots(entry.target, hex, 0);
      } else {
        visibleThumbs.delete(id);
      }
    }
  }
}, { rootMargin: "60px" }) : null;

let thumbRaf = null;
let lastThumbRenderTime = 0;
const THUMB_INTERVAL = 100; // 10 FPS

function scheduleThumbRender() {
  if (thumbRaf) return;
  thumbRaf = requestAnimationFrame((now) => {
    thumbRaf = null;
    if (now - lastThumbRenderTime < THUMB_INTERVAL) return;
    lastThumbRenderTime = now;
    const targets = thumbObserver && visibleThumbs.size ? visibleThumbs : thumbs.keys();
    for (const id of targets) {
      const c = thumbs.get(id);
      const hex = lastThumb.get(id);
      if (c && hex) drawDots(c, hex, 0);
    }
  });
}

function previews(ids) {
  if (!ids) return;
  if (ids === pvIds && pv) return;
  if (pv) { pv.close(); pv = null; }
  pvIds = ids;
  if (document.hidden) return;
  pv = new EventSource("/api/previews?ids=" + encodeURIComponent(ids));
  pv.onmessage = ev => {
    for (const part of ev.data.split(";")) {
      const eq = part.indexOf("=");
      if (eq !== -1) {
        const id = part.slice(0, eq), hex = part.slice(eq + 1);
        if (id && hex) {
          lastThumb.set(id, hex);
        }
      }
    }
    scheduleThumbRender();
  };
  pv.onerror = () => {
    // If closed or interrupted, clean up
  };
}

let lastGlowKey = "";
const ambientEl = document.getElementById("mirrorAmbient");
function draw(line) {
  const alice = line[0] === "A";
  const [ar, ag, ab] = drawDots(cv, line, 1);
  const m = Math.max(ar, ag, ab, 1);
  const nr = Math.round(ar/m*255), ng = Math.round(ag/m*255), nb = Math.round(ab/m*255);
  const na = Math.min(1, +(m/88/150).toFixed(2));
  // Fast baked ambient glow via radial-gradient on dedicated GPU composite layer
  const key = `${nr>>4},${ng>>4},${nb>>4},${Math.round(na*6)}`;
  if (key !== lastGlowKey) {
    lastGlowKey = key;
    if (ambientEl) {
      if (na < 0.04) {
        ambientEl.style.opacity = "0";
      } else {
        ambientEl.style.opacity = (na * 0.95).toFixed(2);
        ambientEl.style.background = `radial-gradient(ellipse at 50% 50%, rgb(${nr},${ng},${nb}) 0%, transparent 72%)`;
      }
    }
  }
  const who = line[0];
  setStatus(alice ? "Сейчас панель у Алисы, свет вернётся, когда она закончит"
    : st && !st.power ? "Свет выключен, панель отдана колонке"
    : who === "N" && st ? `Ночной режим, панель погашена до ${st.nightTo}`
    : who === "D" && st ? `Ночной режим: яркость ограничена до ${Math.round((st.nightBrightness ?? 0.1) * 100)}% до ${st.nightTo}`
    : who === "I" ? "Панель уснула без дела, проснётся от звука или любого изменения"
    : "");
}

let es = null;
let liveBuf = null;
let liveRaf = null;

function live() {
  if (es) { es.close(); es = null; }
  es = new EventSource("/api/live");
  es.onmessage = ev => {
    document.body.classList.remove("offline");
    liveBuf = ev.data;
    if (!liveRaf) {
      liveRaf = requestAnimationFrame(() => {
        liveRaf = null;
        const gTab = document.getElementById("tab-glow"); const isGlowActive = document.body.classList.contains("glow-mode") || (gTab && gTab.classList.contains("on"));
        if (liveBuf && isGlowActive) {
          draw(liveBuf);
        }
      });
    }
  };
  es.onerror = () => {
    document.body.classList.add("offline");
    setStatus("Нет связи с колонкой, переподключаюсь");
  };
}
// the stream is the only steady load on the speaker: stop it while the page is hidden
document.addEventListener("visibilitychange", () => {
  if (document.hidden) { if (es) { es.close(); es = null; } if (pv) { pv.close(); pv = null; } }
  else if (cat) {
    live();
    const ids = pvIds; pvIds = ""; previews(ids);
  }
});


let musicSampleSec = 10.0;
try {
  const savedSec = localStorage.getItem('lumya_music_sample');
  if (savedSec !== null) musicSampleSec = parseFloat(savedSec) || 10.0;
} catch (e) {}

function updateMusicMoodUI() {
  const box = $('musicMoodBox');
  if (box) {
    const isMusicPal = st && st.palette === 'music';
    box.hidden = !isMusicPal;
    box.style.display = isMusicPal ? 'block' : 'none';
  }
  const slider = $('musicSample');
  const valOut = $('musicSampleVal');
  if (slider) {
    if (document.activeElement !== slider) slider.value = musicSampleSec;
    sliderFill(slider);
  }
  if (valOut) valOut.textContent = musicSampleSec === 0 ? '0 с' : musicSampleSec.toFixed(1) + ' с';
}

function bindMusicMoodEvents() {
  const slider = $('musicSample');
  if (slider) {
    sliderFill(slider);
    slider.oninput = e => {
      musicSampleSec = parseFloat(e.target.value);
      try { localStorage.setItem('lumya_music_sample', musicSampleSec); } catch (err) {}
      sliderFill(slider);
      const valOut = $('musicSampleVal');
      if (valOut) valOut.textContent = musicSampleSec === 0 ? '0 с' : musicSampleSec.toFixed(1) + ' с';
    };
  }
  const btnMS = $('btnCenterMusicSample');
  if (btnMS) {
    btnMS.onclick = () => {
      musicSampleSec = 5.0;
      try { localStorage.setItem('lumya_music_sample', musicSampleSec); } catch (err) {}
      if (slider) {
        slider.value = 5.0;
        sliderFill(slider);
      }
      const valOut = $('musicSampleVal');
      if (valOut) valOut.textContent = '5.0 с';
    };
  }
  if ($('musicSampleVal')) {
    $('musicSampleVal').style.cursor = 'pointer';
    $('musicSampleVal').title = 'Центрировать (5 с)';
    $('musicSampleVal').onclick = () => { if (btnMS) btnMS.click(); };
  }
}

async function start() {
  setStatus("");
  try {
    [cat, st] = await Promise.all([api("/api/catalog"), api("/api/state")]);
    loadPresets();
    bindMusicMoodEvents();
    updateMusicMoodUI();
    const cur = cat.effects.find(e => e.id === st.effect);
    tab = cur && !cur.music ? "calm" : "music";
    setTab(tab);
    const gTab = document.getElementById("tab-glow");
    if (document.body.classList.contains("glow-mode") || (gTab && gTab.classList.contains("on"))) {
      live();
    }
  } catch (e) {
    document.body.classList.add("offline");
    $("now").textContent = "Нет связи";
    console.error("Glow start error:", e); if ($("desc")) $("desc").textContent = "Колонка не ответила: " + (e.message || e);
    setStatus("", true);
  }
}

window.glowTabActivated = () => {
  if (!cat) {
    start();
  } else {
    live();
    if (tab !== "presets" && tab !== "params") {
      const ids = pvIds; pvIds = ""; previews(ids);
    }
  }
};
window.glowTabDeactivated = () => {
  if (es) { es.close(); es = null; }
  if (pv) { pv.close(); pv = null; pvIds = ""; }
};

start();

})();

    // Check if initial tab was glow
    try {
      if (localStorage.getItem('tab') === 'glow') {
        setGlowMode(true);
        const btn = document.getElementById('nav-glow-btn');
        if (btn) btn.click();
      }
    } catch (e) {}
  }

  // Hook for Mod Loader teardown
  window.destroyMod_lumya = function() {
    document.body.classList.remove('glow-mode');
    if (typeof window.glowTabDeactivated === 'function') window.glowTabDeactivated();
    const navBtn = document.getElementById('nav-glow-btn');
    if (navBtn) navBtn.remove();
    const glowTab = document.getElementById('tab-glow');
    if (glowTab) glowTab.remove();
    const ambiBtn = document.querySelector('#tab-settings .subnav button[data-sub="light"]');
    if (ambiBtn && ambiBtn.dataset.origText) ambiBtn.textContent = ambiBtn.dataset.origText;
    const ambiSub = document.querySelector('#tab-settings .sub[data-sub="light"]');
    if (ambiSub && ambiSub.dataset.origHtml) ambiSub.innerHTML = ambiSub.dataset.origHtml;
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initLumya);
  } else {
    initLumya();
  }
})();
